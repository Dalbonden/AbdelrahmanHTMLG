/* AEGIS Console — Analyses log with localStorage persistence */
function AnalysesView({ onOpen }) {
  useLucide();
  const [filter, setFilter] = React.useState("All");
  const { history } = useAegis();

  // Static sample analyses (shown when no real history exists)
  const samples = [
    { t: "EU mid-market expansion", v: "VALIDATE FIRST", c: "High", d: "Today · 09:12", tag: "Strategy" },
    { t: "$1.2M cloud commit (2-year)", v: "BUILD", c: "Moderate", d: "Yesterday", tag: "Finance" },
    { t: "Acquire vs build: analytics layer", v: "PIVOT", c: "Moderate", d: "2 days ago", tag: "Strategy" },
    { t: "Series B timing & dilution", v: "VALIDATE FIRST", c: "Low", d: "Last week", tag: "Finance" },
    { t: "Offshore eng pod — risk review", v: "REJECT", c: "High", d: "Last week", tag: "Risk" },
  ];

  // Extract structured analyses from chat history
  const derived = React.useMemo(() => {
    const out = [];
    for (let i = 0; i < history.length; i++) {
      const msg = history[i];
      if (msg.role !== 'assistant') continue;
      const text = typeof msg.content === 'string' ? msg.content : msg.content?.[0]?.text || '';
      try {
        let json = null;
        const fence = text.match(/```(?:json)?\s*(\{[\s\S]*?\})\s*```/);
        if (fence) json = JSON.parse(fence[1]);
        else if (text.trim().startsWith('{')) json = JSON.parse(text.trim());
        if (json && json.verdict && json.summary) {
          const userMsg = history[i - 1];
          const q = userMsg ? (typeof userMsg.content === 'string' ? userMsg.content : userMsg.content?.[0]?.text || '') : '';
          out.push({
            t: q.slice(0, 80) || json.summary.slice(0, 80),
            v: json.verdict,
            c: json.confidence || 'Moderate',
            d: 'Recent',
            tag: 'Live',
            raw: q,
          });
        }
      } catch {}
    }
    return out.slice(0, 20).reverse();
  }, [history]);

  const rows = derived.length > 0 ? derived : samples;
  const tags = ["All", ...Array.from(new Set(rows.map(r => r.tag)))];
  const filtered = filter === "All" ? rows : rows.filter(r => r.tag === filter);

  const verdictColor = v => {
    if (v === "BUILD") return "var(--positive)";
    if (v === "REJECT") return "var(--critical)";
    if (v === "PIVOT") return "var(--warning)";
    return "var(--accent)";
  };

  return (
    <div className="content scrolltrack">
      <div className="content-pad fadeup">
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 22 }}>
          <div>
            <Label>Decision log &middot; {rows.length} {derived.length > 0 ? "live" : "sample"} analyses</Label>
            <h1 style={{ font: "var(--text-h1)", margin: "10px 0 0", letterSpacing: "-0.01em" }}>Analyses</h1>
          </div>
          <button className="btn btn-primary" onClick={() => onOpen()}><Icon name="terminal" cls="ic-16" />New analysis</button>
        </div>

        {/* Stats tiles */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: "Total analyses", val: rows.length, sub: "all time" },
            { label: "Build decisions", val: rows.filter(r => r.v === "BUILD").length, sub: "proceed", col: "var(--positive)" },
            { label: "Validate first", val: rows.filter(r => r.v === "VALIDATE FIRST").length, sub: "needs validation", col: "var(--accent)" },
            { label: "Rejected", val: rows.filter(r => r.v === "REJECT" || r.v === "PIVOT").length, sub: "rejected or pivoted", col: "var(--critical)" },
          ].map((tile, i) => (
            <div className="card tile" key={i}>
              <Label>{tile.label}</Label>
              <span className="metric" style={{ fontSize: 28, color: tile.col || "var(--fg-1)" }}>{tile.val}</span>
              <span style={{ font: "var(--text-mono)", fontSize: 11, color: "var(--fg-3)" }}>{tile.sub}</span>
            </div>
          ))}
        </div>

        {/* Filter bar */}
        {tags.length > 1 && (
          <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
            {tags.map(tag => (
              <button key={tag} className={`btn ${filter === tag ? "btn-primary" : "btn-ghost"}`}
                style={{ fontSize: 11, padding: "3px 10px" }}
                onClick={() => setFilter(tag)}>{tag}</button>
            ))}
          </div>
        )}

        <div className="card" style={{ overflow: "hidden", marginBottom: 16 }}>
          {filtered.length === 0 ? (
            <div style={{ padding: "40px 20px", textAlign: "center", color: "var(--fg-3)" }}>
              <Icon name="inbox" cls="ic-24" />
              <p style={{ marginTop: 12, font: "var(--text-body-sm)" }}>No analyses yet. Start by asking AEGIS a strategic question.</p>
            </div>
          ) : filtered.map((r, i) => (
            <div
              key={i}
              onClick={() => onOpen(r.raw || r.t)}
              style={{
                display: "grid",
                gridTemplateColumns: "1fr auto auto auto auto",
                gap: 14,
                alignItems: "center",
                padding: "14px 20px",
                borderBottom: i < filtered.length - 1 ? "1px solid var(--line)" : "none",
                cursor: "pointer",
                transition: "background .14s",
              }}
              onMouseEnter={e => e.currentTarget.style.background = "var(--bg-raised)"}
              onMouseLeave={e => e.currentTarget.style.background = ""}
            >
              <span style={{ fontSize: 14, color: "var(--fg-1)", lineHeight: 1.4 }}>{r.t}</span>
              <span className="label" style={{ fontSize: 10, color: "var(--fg-4)" }}>{r.tag}</span>
              <Confidence level={r.c} />
              <Verdict label={r.v} />
              <span className="label" style={{ minWidth: 80, textAlign: "right", color: "var(--fg-4)" }}>{r.d}</span>
            </div>
          ))}
        </div>

        {/* Re-run suggestions */}
        <div className="card" style={{ padding: "16px 20px" }}>
          <Label style={{ marginBottom: 12, display: "block" }}>Start a new analysis</Label>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {[
              "Should we expand into EU mid-market?",
              "Evaluate our Series B timing",
              "Build vs buy: data analytics layer",
              "Assess competitive moat vs Competitor A",
              "Is our burn rate sustainable at current growth?",
            ].map((q, i) => (
              <button key={i} className="btn btn-secondary" style={{ fontSize: 12 }} onClick={() => onOpen(q)}>{q}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { AnalysesView });
