/* AEGIS Console — Automations view */

function AutomationsView({ onAsk }) {
  useLucide();
  const [automations, setAutomations] = useState([
    { id: 1, name: "Daily briefing digest", desc: "Compile overnight signals and prepare morning briefing summary", category: "Reporting", icon: "layout-dashboard", enabled: true, lastRun: "Today 07:00", runs: 247, status: "ok" },
    { id: 2, name: "Runway alert", desc: "Alert when projected runway drops below 15 months based on current burn", category: "Monitoring", icon: "alert-triangle", enabled: true, lastRun: "2 hrs ago", runs: 89, status: "ok" },
    { id: 3, name: "Competitor signal tracker", desc: "Monitor public filings, press releases, and job postings for competitive intelligence", category: "Intelligence", icon: "activity", enabled: true, lastRun: "1 hr ago", runs: 412, status: "warn" },
    { id: 4, name: "Risk matrix refresh", desc: "Re-score all active risks weekly based on new data and escalate Critical findings", category: "Monitoring", icon: "shield-check", enabled: true, lastRun: "Yesterday", runs: 52, status: "ok" },
    { id: 5, name: "Secrets rotation reminder", desc: "Check rotation schedules and flag overdue credentials 7 days in advance", category: "Security", icon: "key", enabled: false, lastRun: "14 days ago", runs: 31, status: "err" },
    { id: 6, name: "Board report generator", desc: "Compile monthly metrics, risk summary, and decision log into board-ready deck", category: "Reporting", icon: "file-text", enabled: false, lastRun: "3 weeks ago", runs: 14, status: "ok" },
    { id: 7, name: "Burn anomaly detector", desc: "Flag unexpected spend spikes (>15% MoM) against budget and surface causal analysis", category: "Monitoring", icon: "trending-up", enabled: true, lastRun: "6 hrs ago", runs: 180, status: "ok" },
    { id: 8, name: "Market open summary", desc: "Post-market-open snapshot of relevant indices, FX moves, and sector signals", category: "Intelligence", icon: "line-chart", enabled: true, lastRun: "Today 09:35", runs: 198, status: "ok" },
  ]);

  const [running, setRunning] = useState(null);
  const [filter, setFilter] = useState('All');
  const categories = ['All', 'Monitoring', 'Intelligence', 'Reporting', 'Security'];

  const toggle = (id) => {
    setAutomations(a => a.map(x => x.id === id ? { ...x, enabled: !x.enabled } : x));
    const auto = automations.find(x => x.id === id);
    toast(`${auto.name} ${auto.enabled ? 'disabled' : 'enabled'}`, 'info');
  };

  const runNow = async (id) => {
    setRunning(id);
    await new Promise(r => setTimeout(r, 1800));
    setRunning(null);
    setAutomations(a => a.map(x => x.id === id ? { ...x, lastRun: 'Just now', runs: x.runs + 1, status: 'ok' } : x));
    const auto = automations.find(x => x.id === id);
    toast(`${auto.name} completed`, 'success');
  };

  const statusColor = { ok: 'var(--positive)', warn: 'var(--warning)', err: 'var(--critical)' };
  const statusLabel = { ok: 'OK', warn: 'WARNING', err: 'FAILED' };

  const filtered = filter === 'All' ? automations : automations.filter(a => a.category === filter);
  const enabled = automations.filter(a => a.enabled).length;

  return (
    <div className="content scrolltrack">
      <div className="content-pad fadeup">
        {/* Header */}
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 22 }}>
          <div>
            <Label>Execution layer</Label>
            <h1 style={{ font: "var(--text-h1)", margin: "10px 0 0", letterSpacing: "-0.01em" }}>Automations</h1>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary" onClick={onAsk}><Icon name="terminal" cls="ic-16" />Ask AEGIS</button>
            <button className="btn btn-primary" onClick={() => toast('New automation builder coming soon', 'info')}>
              <Icon name="plus" cls="ic-16" />New automation
            </button>
          </div>
        </div>

        {/* Summary tiles */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 24 }}>
          <MetricTile label="Active" value={enabled} delta={`of ${automations.length} total`} tone="up" />
          <MetricTile label="Runs today" value="12" delta="across 6 automations" tone="muted" />
          <MetricTile label="Failures" value="1" delta="secrets rotation" tone="down" />
          <MetricTile label="Total executions" value="1,223" delta="last 30 days" tone="muted" />
        </div>

        {/* Filter */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 16 }}>
          {categories.map(c => (
            <button key={c} className={`btn ${filter === c ? 'btn-secondary' : 'btn-ghost'}`}
              style={{ fontSize: 12, padding: '6px 12px' }} onClick={() => setFilter(c)}>{c}</button>
          ))}
        </div>

        {/* Automations list */}
        <div className="card" style={{ overflow: 'hidden' }}>
          {filtered.map((a, i) => (
            <div key={a.id} style={{ display: 'grid', gridTemplateColumns: 'auto 1fr auto auto auto', gap: 16, alignItems: 'center', padding: '16px 20px', borderBottom: i < filtered.length - 1 ? '1px solid var(--line)' : 'none', transition: 'background .14s' }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-raised)'}
              onMouseLeave={e => e.currentTarget.style.background = ''}>

              {/* Icon */}
              <div style={{ width: 36, height: 36, borderRadius: 'var(--r-md)', background: 'var(--bg-raised)', border: '1px solid var(--line)', display: 'grid', placeItems: 'center', color: a.enabled ? 'var(--accent)' : 'var(--fg-4)' }}>
                <Icon name={a.icon} cls="ic-18" />
              </div>

              {/* Info */}
              <div style={{ minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                  <span style={{ fontSize: 14, fontWeight: 500, color: a.enabled ? 'var(--fg-1)' : 'var(--fg-3)' }}>{a.name}</span>
                  <span className="pill" style={{ fontSize: 10, padding: '2px 8px', background: 'var(--bg-raised)', color: 'var(--fg-4)' }}>{a.category}</span>
                </div>
                <div style={{ fontSize: 12.5, color: 'var(--fg-3)', lineHeight: 1.4 }}>{a.desc}</div>
                <div style={{ display: 'flex', gap: 12, marginTop: 5 }}>
                  <span style={{ font: 'var(--text-mono)', fontSize: 11, color: 'var(--fg-4)' }}>Last run: {a.lastRun}</span>
                  <span style={{ font: 'var(--text-mono)', fontSize: 11, color: 'var(--fg-4)' }}>{a.runs} runs</span>
                  <span style={{ font: 'var(--text-mono)', fontSize: 11, color: statusColor[a.status] }}>{statusLabel[a.status]}</span>
                </div>
              </div>

              {/* Run now */}
              <button className="btn btn-ghost" style={{ fontSize: 12, padding: '6px 10px', opacity: !a.enabled ? 0.4 : 1 }}
                disabled={running === a.id || !a.enabled} onClick={() => runNow(a.id)}>
                {running === a.id ? <Spinner size={14} /> : <Icon name="play" cls="ic-14" />}
                {running === a.id ? 'Running' : 'Run'}
              </button>

              {/* Toggle */}
              <label className="toggle">
                <input type="checkbox" checked={a.enabled} onChange={() => toggle(a.id)} />
                <div className="toggle-track"></div>
                <div className="toggle-thumb"></div>
              </label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { AutomationsView });
