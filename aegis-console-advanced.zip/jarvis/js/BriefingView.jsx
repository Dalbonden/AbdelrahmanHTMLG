/* AEGIS Console — Briefing (dashboard) view */
function BriefingView({ onOpenAnalysis }) {
  useLucide();
  const { apiKey } = useAegis();

  const risks = [
    { item: "EU regulatory load on mid-market GTM", level: "High", trend: "↑" },
    { item: "Single-vendor cloud concentration", level: "Medium", trend: "→" },
    { item: "Burn outpacing net-new ARR", level: "Medium", trend: "↑" },
    { item: "Founder key-person dependency", level: "Critical", trend: "→" },
    { item: "Secrets rotation overdue (3 services)", level: "High", trend: "↓" },
  ];

  const pending = [
    "Approve Q3 hiring plan (4 reqs)",
    "Sign cloud commit — $1.2M / 2yr",
    "Greenlight security audit vendor",
  ];

  return (
    <div className="content-pad fadeup">
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <Label>Daily briefing &middot; {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}</Label>
          <h1 style={{ font: "var(--text-h1)", margin: "10px 0 6px", letterSpacing: "-0.01em" }}>Good morning, Principal.</h1>
          <p style={{ font: "var(--text-body-lg)", color: "var(--fg-2)", margin: 0, maxWidth: 600, lineHeight: 1.55 }}>
            Three items need a decision today. Runway is stable; one risk escalated to{" "}
            <span style={{ color: "var(--critical)" }}>critical</span>.
            {!apiKey && <span style={{ color: "var(--warning)" }}> Configure your API key to enable AI analysis.</span>}
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => onOpenAnalysis()}>
          <Icon name="terminal" cls="ic-16" />New analysis
        </button>
      </div>

      {/* KPI tiles */}
      <div className="grid-metrics" style={{ marginBottom: 24 }}>
        <MetricTile label="ARR" value="$23.8M" delta="▲ 14.2% QoQ" tone="up" onClick={() => onOpenAnalysis("How healthy is our ARR growth at 14.2% QoQ?")} />
        <MetricTile label="Burn / mo" value="$640K" delta="▲ 6.0% MoM" tone="warn" onClick={() => onOpenAnalysis("Analyze our burn rate of $640K/mo — is it sustainable?")} />
        <MetricTile label="Runway" value="18" unit="mo" delta="stable" tone="muted" onClick={() => onOpenAnalysis("Stress-test our 18-month runway")} />
        <MetricTile label="NRR" value="118%" delta="▲ 2.0 pts QoQ" tone="up" onClick={() => onOpenAnalysis("What does 118% NRR signal about our expansion motion?")} />
      </div>

      {/* Risk matrix + sidebar */}
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16, marginBottom: 16 }}>
        <div className="card" style={{ padding: "18px 20px" }}>
          <SectionHead kicker="Risk assessment" title="Active risk matrix" right={
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <span className="label">5 TRACKED</span>
              <button className="btn btn-ghost" style={{ fontSize: 12, padding: '4px 8px' }} onClick={() => onOpenAnalysis("Give me a comprehensive risk assessment across our active risk register")}>
                <Icon name="terminal" cls="ic-14" />Analyze
              </button>
            </div>
          } />
          <div>
            {risks.map((r, i) => (
              <div className="matrix-row" key={i} style={{ cursor: 'pointer' }} onClick={() => onOpenAnalysis(`Analyze the risk: "${r.item}"`)}>
                <span style={{ fontSize: 14, color: "var(--fg-1)", lineHeight: 1.4 }}>{r.item}</span>
                <span className="label" style={{ color: "var(--fg-3)" }}>{r.trend}</span>
                <RiskPill level={r.level} />
              </div>
            ))}
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="card glow" style={{ padding: "18px 20px" }}>
            <Label style={{ color: "var(--accent)" }}>Recommendation &middot; today</Label>
            <h3 style={{ font: "var(--text-h4)", margin: "10px 0 8px" }}>Stage the EU launch — don't commit eng yet.</h3>
            <p style={{ font: "var(--text-body-sm)", color: "var(--fg-2)", margin: "0 0 14px", lineHeight: 1.5 }}>
              Demand signal is strong but regulatory exposure gates timeline. Run 3 design partners first.
            </p>
            <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: 'wrap' }}>
              <Verdict label="VALIDATE FIRST" />
              <Confidence level="High" />
            </div>
          </div>

          <div className="card" style={{ padding: "18px 20px" }}>
            <Label>Awaiting your decision</Label>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 12 }}>
              {pending.map((t, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 14, color: "var(--fg-1)", cursor: "pointer", padding: '4px 0' }}
                  onClick={() => onOpenAnalysis(t)}>
                  <Icon name="circle-dot" cls="ic-16" style={{ flex: 'none', color: 'var(--accent)' }} />
                  <span style={{ flex: 1, lineHeight: 1.4 }}>{t}</span>
                  <Icon name="arrow-right" cls="ic-14" style={{ flex: 'none', color: 'var(--fg-4)' }} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Quick analysis prompts */}
      <div className="card" style={{ padding: "16px 20px" }}>
        <SectionHead kicker="Quick analysis" title="Jump to decision" />
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {[
            "Should we expand into EU mid-market?",
            "Evaluate the $1.2M cloud commit",
            "Analyze our Series B timing",
            "Review our hiring plan for Q3",
            "Assess our competitive position",
            "Analyze the offshore eng pod risk",
          ].map((q, i) => (
            <button key={i} className="btn btn-secondary" style={{ fontSize: 12 }} onClick={() => onOpenAnalysis(q)}>{q}</button>
          ))}
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { BriefingView });
