/* AEGIS Console — Ask AEGIS (real Claude API, streaming, multi-turn) */

function ExecResponse({ data, raw }) {
  useLucide();
  const json = JSON.stringify(data, null, 2);
  const md = `# ${data.verdict || 'ANALYSIS'} — Confidence: ${data.confidence}\n\n## Executive Summary\n${data.summary}\n\n## Key Findings\n${(data.findings||[]).map((f,i)=>`${i+1}. ${f}`).join('\n')}\n\n## Analysis\n${(data.analysis||[]).map(a=>`**${a.head}**: ${a.body}`).join('\n\n')}\n\n## Risks\n${(data.risks||[]).map(r=>`- [${r.level}] ${r.item} — ${r.mitigation}`).join('\n')}\n\n## Recommendations\n${(data.recommendations||[]).map((r,i)=>`${i+1}. ${r}`).join('\n')}\n\n## Next Steps\n${(data.next||[]).map(n=>`- ${n}`).join('\n')}`;

  return (
    <div className="fadeup" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      {/* Executive summary */}
      <div className="card glow" style={{ padding: "18px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10, flexWrap: 'wrap' }}>
          <Label style={{ color: "var(--accent)" }}>Executive summary</Label>
          <span style={{ marginLeft: "auto", display: "flex", gap: 8, flexWrap: 'wrap' }}>
            {data.verdict && <Verdict label={data.verdict} />}
            <Confidence level={data.confidence} />
          </span>
        </div>
        <p style={{ font: "var(--text-body-lg)", color: "var(--fg-1)", margin: 0, lineHeight: 1.6 }}>{data.summary}</p>
        <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
          <CopyBtn text={md} label="Copy as markdown" />
          <CopyBtn text={json} label="Copy JSON" />
        </div>
      </div>

      {/* Key findings */}
      {data.findings && data.findings.length > 0 && (
        <div>
          <Label>Key findings</Label>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 10 }}>
            {data.findings.map((f, i) => (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: 12, alignItems: "baseline" }}>
                <span style={{ font: "var(--text-mono)", fontSize: 12, color: "var(--accent)", minWidth: 20 }}>{String(i + 1).padStart(2, "0")}</span>
                <span style={{ fontSize: 15, color: "var(--fg-1)", lineHeight: 1.5 }}>{f}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Analysis quadrants */}
      {data.analysis && data.analysis.length > 0 && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {data.analysis.map((a, i) => (
            <div className="card" key={i} style={{ padding: "14px 16px" }}>
              <Label>{a.head}</Label>
              <p style={{ font: "var(--text-body-sm)", color: "var(--fg-2)", margin: "8px 0 0", lineHeight: 1.55 }}>{a.body}</p>
            </div>
          ))}
        </div>
      )}

      {/* Risks */}
      {data.risks && data.risks.length > 0 && (
        <div className="card" style={{ padding: "16px 20px" }}>
          <Label>Risk assessment</Label>
          <div style={{ marginTop: 8 }}>
            {data.risks.map((r, i) => (
              <div className="matrix-row" key={i} style={{ gridTemplateColumns: "1fr auto" }}>
                <span style={{ fontSize: 14, color: "var(--fg-1)" }}>
                  {r.item}
                  {r.mitigation && <span style={{ color: "var(--fg-3)", display: "block", fontSize: 12.5, marginTop: 3, lineHeight: 1.4 }}>{r.mitigation}</span>}
                </span>
                <RiskPill level={r.level} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recommendations + Next steps */}
      {(data.recommendations?.length > 0 || data.next?.length > 0) && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {data.recommendations && data.recommendations.length > 0 && (
            <div>
              <Label>Recommendations</Label>
              <ol style={{ margin: "10px 0 0", paddingLeft: 18, color: "var(--fg-1)", fontSize: 14, display: "flex", flexDirection: "column", gap: 7, lineHeight: 1.5 }}>
                {data.recommendations.map((r, i) => <li key={i} style={{ paddingLeft: 4 }}>{r}</li>)}
              </ol>
            </div>
          )}
          {data.next && data.next.length > 0 && (
            <div>
              <Label>Next steps</Label>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 10 }}>
                {data.next.map((n, i) => (
                  <div key={i} style={{ display: "flex", gap: 9, alignItems: "flex-start", fontSize: 14, color: "var(--fg-1)", lineHeight: 1.4 }}>
                    <Icon name="arrow-right" cls="ic-16" style={{ flex: 'none', marginTop: 2 }} />
                    <span>{n}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ChatView({ seeded, initialQuery }) {
  useLucide();
  const { apiKey, model, history, setHistory } = useAegis();

  const [thread, setThread] = useState(() => {
    if (seeded) return [
      { role: "user", text: "Should we expand into the EU mid-market this year?" },
      { role: "aegis", data: DEMO_RESPONSE },
    ];
    return [];
  });
  const [input, setInput] = useState(initialQuery || "");
  const [thinking, setThinking] = useState(false);
  const [streamText, setStreamText] = useState("");
  const [apiErr, setApiErr] = useState(null);
  const [voiceState, setVoiceState] = useState("idle"); // idle | listening | processing
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const recognitionRef = useRef(null);

  const startVoice = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { toast("Voice input not supported in this browser. Use Chrome or Edge.", "error"); return; }
    if (voiceState === "listening") {
      recognitionRef.current?.stop();
      return;
    }
    const rec = new SR();
    rec.lang = "en-US";
    rec.continuous = false;
    rec.interimResults = true;
    rec.maxAlternatives = 1;
    recognitionRef.current = rec;

    let finalTranscript = "";
    rec.onstart = () => setVoiceState("listening");
    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) finalTranscript += e.results[i][0].transcript;
        else interim = e.results[i][0].transcript;
      }
      setInput(finalTranscript || interim);
      if (inputRef.current) {
        inputRef.current.style.height = "auto";
        inputRef.current.style.height = Math.min(inputRef.current.scrollHeight, 160) + "px";
      }
    };
    rec.onerror = (e) => { setVoiceState("idle"); if (e.error !== "no-speech") toast(`Voice error: ${e.error}`, "error"); };
    rec.onend = () => {
      setVoiceState(finalTranscript ? "processing" : "idle");
      if (finalTranscript.trim()) {
        setTimeout(() => { setVoiceState("idle"); send(finalTranscript.trim()); }, 300);
      }
    };
    rec.start();
  };

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [thread, thinking, streamText]);

  useEffect(() => {
    if (inputRef.current) inputRef.current.focus();
  }, []);

  useEffect(() => {
    if (initialQuery && initialQuery.trim()) {
      send(initialQuery);
    }
  }, []);

  const send = async (text) => {
    const q = (text ?? input).trim();
    if (!q || thinking) return;

    if (!apiKey) {
      setApiErr('no-key');
      return;
    }

    const newMsg = { role: "user", text: q };
    setThread(t => [...t, newMsg]);
    setInput("");
    setThinking(true);
    setStreamText("");
    setApiErr(null);

    const msgs = [
      ...history,
      { role: "user", content: q },
    ];

    try {
      let rawText = '';
      await callAegis(msgs, apiKey, model, (accumulated) => {
        setStreamText(accumulated);
        rawText = accumulated;
      });

      const data = parseAegisResponse(rawText || streamText);
      setThread(t => [...t, { role: "aegis", data, raw: rawText }]);
      setHistory(prev => [
        ...prev,
        { role: "user", content: q },
        { role: "assistant", content: rawText },
      ]);
    } catch (err) {
      setThread(t => [...t, { role: "error", text: err.message }]);
    } finally {
      setThinking(false);
      setStreamText("");
    }
  };

  const clearThread = () => {
    setThread([]);
    setHistory([]);
    toast('Conversation cleared', 'info');
  };

  const suggestions = [
    "Should we expand into the EU mid-market?",
    "Evaluate our $1.2M cloud commit",
    "Stress-test our 18-month runway",
    "Should we acquire or build our analytics layer?",
  ];

  return (
    <React.Fragment>
      <div className="content scrolltrack" ref={scrollRef}>
        <div className="content-pad">
          {thread.length === 0 && !thinking && (
            <div className="fadeup" style={{ paddingTop: 40, textAlign: "center" }}>
              <div style={{ color: "var(--fg-1)", display: "inline-flex" }}>
                <img src="assets/logo-mark.svg" width="52" alt="AEGIS" />
              </div>
              <h1 style={{ font: "var(--text-h2)", margin: "16px 0 6px" }}>Ask AEGIS</h1>
              <p style={{ color: "var(--fg-3)", margin: "0 auto 24px", maxWidth: 500, lineHeight: 1.6 }}>
                {apiKey
                  ? "Pose any decision. Receive an executive-grade analysis: findings, risks, recommendations, and a verdict."
                  : "Enter your Anthropic API key in Settings to enable real AI analysis."}
              </p>
              {!apiKey && (
                <button className="btn btn-primary" style={{ marginBottom: 24 }} onClick={() => window._aegisSetView && window._aegisSetView('settings')}>
                  <Icon name="settings" cls="ic-16" />Configure API key
                </button>
              )}
              <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap" }}>
                {suggestions.map((s, i) => (
                  <button key={i} className="btn btn-secondary" style={{ fontSize: 13 }} onClick={() => send(s)}>{s}</button>
                ))}
              </div>
            </div>
          )}

          <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
            {thread.map((m, i) => {
              if (m.role === "user") return (
                <div key={i} style={{ alignSelf: "flex-end", maxWidth: "72%" }}>
                  <div style={{ background: "var(--bg-raised)", border: "1px solid var(--line)", borderRadius: "var(--r-lg)", padding: "12px 16px", fontSize: 15, lineHeight: 1.55 }}>{m.text}</div>
                </div>
              );
              if (m.role === "error") return (
                <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <div style={{ flex: "none", width: 30, height: 30 }}><img src="assets/logo-mark.svg" width="30" alt="AEGIS" /></div>
                  <div className="card" style={{ padding: "14px 16px", borderColor: "var(--accent-line)", flex: 1 }}>
                    <Label style={{ color: "var(--critical)" }}>System error</Label>
                    <p style={{ font: "var(--text-body-sm)", color: "var(--fg-2)", margin: "6px 0 0" }}>{m.text}</p>
                  </div>
                </div>
              );
              return (
                <div key={i} style={{ display: "flex", gap: 12 }}>
                  <div style={{ flex: "none", width: 30, height: 30, paddingTop: 2 }}><img src="assets/logo-mark.svg" width="30" alt="AEGIS" /></div>
                  <div style={{ flex: 1, minWidth: 0 }}><ExecResponse data={m.data} raw={m.raw} /></div>
                </div>
              );
            })}

            {thinking && (
              <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                <div style={{ flex: "none", width: 30, height: 30 }}><img src="assets/logo-mark.svg" width="30" alt="AEGIS" /></div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  {streamText ? (
                    <div className="card" style={{ padding: "14px 16px" }}>
                      <Label style={{ color: "var(--accent)", marginBottom: 8, display: 'block' }}>Analyzing<span className="thinking-dots"><span>.</span><span>.</span><span>.</span></span></Label>
                      <div className="stream-text stream-cursor">{streamText}</div>
                    </div>
                  ) : (
                    <div style={{ display: "flex", alignItems: "center", gap: 10, color: "var(--fg-3)", paddingTop: 4 }}>
                      <Spinner size={16} />
                      <span className="label">ANALYZING<span className="thinking-dots"><span>.</span><span>.</span><span>.</span></span></span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Input bar */}
      <div style={{ borderTop: "1px solid var(--line)", padding: "14px 28px 16px", background: "var(--bg-app)", flexShrink: 0 }}>
        {apiErr === 'no-key' && (
          <div style={{ marginBottom: 10, display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--warning)' }}>
            <Icon name="alert-triangle" cls="ic-14" />
            No API key configured.
            <button className="btn btn-ghost" style={{ fontSize: 12, padding: '4px 8px' }} onClick={() => window._aegisSetView && window._aegisSetView('settings')}>
              Open Settings →
            </button>
          </div>
        )}
        <div style={{ maxWidth: 1080, margin: "0 auto", display: "flex", gap: 8, alignItems: "flex-end" }}>
          <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 10, background: "var(--bg-inset)", border: `1px solid ${voiceState === "listening" ? "var(--critical)" : "var(--line-strong)"}`, borderRadius: "var(--r-lg)", padding: "10px 10px 10px 16px", transition: "border-color .2s" }}>
            <Icon name="terminal" cls="ic-18" style={{ color: voiceState === "listening" ? "var(--critical)" : undefined }} />
            <textarea
              ref={inputRef}
              value={input}
              rows={1}
              onChange={e => {
                setInput(e.target.value);
                e.target.style.height = 'auto';
                e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px';
              }}
              onKeyDown={e => {
                if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
              }}
              placeholder={voiceState === "listening" ? "Listening… speak now" : "Ask AEGIS to analyze any decision…"}
              style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "var(--fg-1)", font: "var(--text-body)", resize: "none", overflow: "hidden", minHeight: 22, maxHeight: 160, lineHeight: 1.5 }}
            />

            {/* Mic button */}
            <button
              onClick={startVoice}
              disabled={thinking}
              title={voiceState === "listening" ? "Stop recording" : "Voice input"}
              style={{
                background: voiceState === "listening" ? "var(--critical)" : "transparent",
                border: `1px solid ${voiceState === "listening" ? "var(--critical)" : "var(--line-strong)"}`,
                borderRadius: "var(--r-sm)",
                padding: "6px 8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                color: voiceState === "listening" ? "#fff" : "var(--fg-3)",
                transition: "all .2s",
                flexShrink: 0,
                animation: voiceState === "listening" ? "mic-pulse 1.2s ease-in-out infinite" : "none",
              }}
            >
              <Icon name={voiceState === "listening" ? "mic-off" : "mic"} cls="ic-16" />
            </button>

            <button className="btn btn-primary" onClick={() => send()} disabled={thinking || !input.trim()}>
              <Icon name="arrow-up" cls="ic-16" />Run
            </button>
          </div>
          {thread.length > 0 && (
            <button className="btn btn-ghost" onClick={clearThread} title="Clear conversation" style={{ padding: '10px 12px', flexShrink: 0 }}>
              <Icon name="trash-2" cls="ic-16" />
            </button>
          )}
        </div>
        <div style={{ maxWidth: 1080, margin: '6px auto 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ font: "var(--text-mono)", fontSize: 11, color: "var(--fg-4)" }}>
            Enter to send · Shift+Enter for new line · Ctrl+K palette
            {voiceState === "listening" && <span style={{ color: "var(--critical)", marginLeft: 10 }}>&#9679; Recording — click mic to stop</span>}
            {voiceState === "processing" && <span style={{ color: "var(--accent)", marginLeft: 10 }}>Processing voice…</span>}
          </span>
          {apiKey && <span style={{ font: "var(--text-mono)", fontSize: 11, color: "var(--fg-4)" }}>{model || 'claude-opus-4-8'}</span>}
        </div>
      </div>
    </React.Fragment>
  );
}

/* Demo response for seeded view (shown when no API key yet) */
const DEMO_RESPONSE = {
  verdict: "VALIDATE FIRST",
  confidence: "High",
  summary: "Entering the EU mid-market is directionally correct but premature to build against. The demand signal is real; the binding constraint is regulatory and operational readiness, not product. Stage it: validate with design partners, stand up compliance, then commit engineering.",
  findings: [
    "Inbound from EU accounts is up 41% QoQ with no localized GTM — latent demand is real.",
    "GDPR + data-residency requirements add ~9–13 weeks before a compliant launch is possible.",
    "Two competitors already hold SOC 2 + EU hosting; we trail on trust signals, not features.",
    "Estimated incremental ARR: €2.1–3.4M in year one at moderate confidence.",
  ],
  analysis: [
    { head: "Strategic", body: "Strong fit with up-market motion; widens TAM ~28%. Defensible only if compliance posture leads, not lags." },
    { head: "Financial", body: "€2.1–3.4M Y1 ARR vs ~$480K setup + 1.5 FTE. ROI positive by Q3 of launch year in the base case." },
    { head: "Technical", body: "Requires EU region, data-residency routing, and audit logging. ~6 eng-weeks; no core re-architecture." },
    { head: "Operational", body: "Bottleneck is compliance + local counsel, not engineering. Sequence those first to de-risk the date." },
  ],
  risks: [
    { item: "Regulatory load (GDPR, residency)", mitigation: "Stage launch; engage local counsel before any commit.", level: "High" },
    { item: "Trust gap vs incumbents", mitigation: "Fast-track SOC 2 Type II; publish EU hosting.", level: "Medium" },
    { item: "Burn impact during ramp", mitigation: "Cap to 1.5 FTE until 3 signed design partners.", level: "Medium" },
  ],
  recommendations: [
    "Sign 3 EU design partners before committing engineering.",
    "Kick off SOC 2 Type II and EU region provisioning in parallel.",
    "Set a go/no-go gate at 60 days tied to partner conversion.",
  ],
  next: ["Draft design-partner shortlist", "Brief counsel on residency", "Schedule 60-day go/no-go", "Model burn sensitivity"],
};

Object.assign(window, { ChatView, ExecResponse });
