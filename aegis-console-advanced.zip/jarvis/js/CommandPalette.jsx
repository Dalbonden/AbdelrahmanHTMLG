/* AEGIS Console — Command palette (Ctrl+K / ⌘K) */

function CommandPalette({ onNav, onClose, recentAnalyses }) {
  useLucide();
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(0);
  const inputRef = useRef(null);

  useEffect(() => { if (inputRef.current) inputRef.current.focus(); }, []);

  const navItems = [
    { type: 'nav', id: 'briefing',    label: 'Briefing',    icon: 'layout-dashboard', hint: 'Daily dashboard' },
    { type: 'nav', id: 'ask',         label: 'Ask AEGIS',   icon: 'terminal',         hint: 'AI analysis' },
    { type: 'nav', id: 'analyses',    label: 'Analyses',    icon: 'file-text',         hint: 'Decision log' },
    { type: 'nav', id: 'markets',     label: 'Markets',     icon: 'line-chart',        hint: 'Market intel' },
    { type: 'nav', id: 'portfolio',   label: 'Portfolio',   icon: 'briefcase',         hint: 'Holdings' },
    { type: 'nav', id: 'security',    label: 'Security',    icon: 'shield-check',      hint: 'Threat register' },
    { type: 'nav', id: 'automations', label: 'Automations', icon: 'git-branch',        hint: 'Execution layer' },
    { type: 'nav', id: 'settings',    label: 'Settings',    icon: 'settings',          hint: 'Configuration' },
  ];

  const quickActions = [
    { type: 'action', label: 'New analysis', icon: 'plus-circle', action: () => { onNav('ask'); onClose(); } },
    { type: 'action', label: 'Clear conversation', icon: 'trash-2', action: () => { window._aegisClearChat && window._aegisClearChat(); onClose(); toast('Conversation cleared', 'info'); } },
  ];

  const analysisItems = (recentAnalyses || []).slice(0, 3).map(a => ({
    type: 'analysis', label: a.text, icon: 'clock', hint: 'Recent', action: () => { onNav('ask'); onClose(); },
  }));

  const q = query.toLowerCase();
  const filtered = [
    ...(q ? [] : [{ section: 'Navigate' }]),
    ...navItems.filter(i => !q || i.label.toLowerCase().includes(q) || i.hint.toLowerCase().includes(q)),
    ...(q ? [] : [{ section: 'Actions' }]),
    ...quickActions.filter(i => !q || i.label.toLowerCase().includes(q)),
    ...(analysisItems.length && !q ? [{ section: 'Recent' }] : []),
    ...analysisItems.filter(i => !q || i.label.toLowerCase().includes(q)),
  ];

  const items = filtered.filter(x => !x.section);
  const flatItems = filtered;
  let flatIdx = 0;
  const indexedItems = flatItems.map(x => x.section ? x : { ...x, _i: flatIdx++ });

  useEffect(() => { setSelected(0); }, [query]);

  const handleKey = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setSelected(s => Math.min(s + 1, items.length - 1)); }
    if (e.key === 'ArrowUp') { e.preventDefault(); setSelected(s => Math.max(s - 1, 0)); }
    if (e.key === 'Enter') {
      const item = items[selected];
      if (item) activate(item);
    }
    if (e.key === 'Escape') onClose();
  };

  const activate = (item) => {
    if (item.type === 'nav') { onNav(item.id); onClose(); }
    if (item.action) item.action();
  };

  return (
    <div className="palette-overlay" onClick={onClose}>
      <div className="palette-box" onClick={e => e.stopPropagation()}>
        <div className="palette-input-row">
          <Icon name="search" cls="ic-18" />
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Search views, actions…"
            style={{ flex: 1, background: 'transparent', border: 'none', color: 'var(--fg-1)', font: 'var(--text-body)', fontSize: 15 }}
          />
          <kbd>Esc</kbd>
        </div>
        <div className="palette-results scrolltrack">
          {(() => {
            let iCount = 0;
            return indexedItems.map((item, i) => {
              if (item.section) return <div key={i} className="palette-section">{item.section}</div>;
              const idx = iCount++;
              return (
                <div key={i} className={`palette-item ${idx === selected ? 'selected' : ''}`}
                  onClick={() => activate(item)}
                  onMouseEnter={() => setSelected(idx)}>
                  <div style={{ width: 32, height: 32, borderRadius: 'var(--r-md)', background: 'var(--bg-active)', display: 'grid', placeItems: 'center', flex: 'none' }}>
                    <Icon name={item.icon} cls="ic-16" />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14, color: 'var(--fg-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.label}</div>
                    {item.hint && <div style={{ font: 'var(--text-mono)', fontSize: 11, color: 'var(--fg-4)', marginTop: 2 }}>{item.hint}</div>}
                  </div>
                  {item.type === 'nav' && <Icon name="arrow-right" cls="ic-14" style={{ color: 'var(--fg-4)', flex: 'none' }} />}
                </div>
              );
            });
          })()}
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { CommandPalette });
