/* AEGIS Console — Markets intelligence view */
function MarketsView({ onAsk }) {
  useLucide();
  const sparkRef1 = useRef(null);
  const sparkRef2 = useRef(null);
  const sparkRef3 = useRef(null);

  function mkSparkline(canvasRef, color, positive) {
    useEffect(() => {
      if (!window.Chart || !canvasRef.current) return;
      const pts = Array.from({ length: 30 }, (_, i) => {
        let v = 100;
        const data = [100];
        for (let j = 1; j <= 30; j++) data.push(data[j-1] * (1 + (positive ? 0.002 : -0.002) + 0.008*(Math.random()-0.5)));
        return data;
      })[0];
      const inst = new Chart(canvasRef.current, {
        type: 'line',
        data: { labels: pts.map((_,i)=>i), datasets: [{ data: pts, borderColor: color, borderWidth: 1.5, pointRadius: 0, fill: false, tension: 0.4 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { display: false }, y: { display: false } }, animation: false },
      });
      return () => inst.destroy();
    }, []);
  }

  mkSparkline(sparkRef1, '#2FB67C', true);
  mkSparkline(sparkRef2, '#E0A53B', false);
  mkSparkline(sparkRef3, '#5B9DD9', true);

  const signals = [
    { ticker: "SAAS INDEX", val: "▲ 3.2%", desc: "Leading SaaS multiples expanded on Fed rate signal", tone: "up", ref: sparkRef1 },
    { ticker: "EUR/USD", val: "1.0847", desc: "Euro strengthened; favorable for EU expansion unit economics", tone: "up", ref: null },
    { ticker: "VC DEAL FLOW", val: "▼ 12%", desc: "Series B deal count down QoQ; valuation discipline tightening", tone: "down", ref: sparkRef2 },
    { ticker: "TALENT INDEX", val: "→ 0.4%", desc: "Engineering compensation flat; no significant wage pressure", tone: "muted", ref: sparkRef3 },
  ];

  const intel = [
    { head: "Competitor A", body: "Raised Series C at 14x ARR. Now moving up-market aggressively. EU launch announced for Q3.", level: "High", action: "Analyze Competitor A's Series C and what it means for our positioning" },
    { head: "Competitor B", body: "Lost 2 enterprise logos to us last month. Pricing pressure likely incoming — monitor Q2 churn.", level: "Low", action: "How should we respond to Competitor B's likely pricing move?" },
    { head: "EU AI Act", body: "EU AI Act compliance deadline approaching. Affects inference pipeline — legal review needed.", level: "Critical", action: "What do we need to do to comply with the EU AI Act?" },
    { head: "VC Sentiment", body: "Series B multiples contracting: median 8x ARR vs 12x in 2023. Raise earlier or at higher growth.", level: "Medium", action: "Given contracting Series B multiples, what's our optimal fundraise strategy?" },
  ];

  const toneColor = t => t === "up" ? "var(--positive)" : t === "down" ? "var(--critical)" : "var(--fg-3)";

  return (
    <div className="content scrolltrack">
      <div className="content-pad fadeup">
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 22 }}>
          <div>
            <Label>Market intelligence &middot; {new Date().toLocaleDateString("en-US", { month: "long", day: "numeric" })}</Label>
            <h1 style={{ font: "var(--text-h1)", margin: "10px 0 0", letterSpacing: "-0.01em" }}>Markets</h1>
          </div>
          <button className="btn btn-primary" onClick={() => onAsk("Give me a current market intelligence briefing covering SaaS multiples, macro environment, competitive landscape, and what it means for our strategy")}><Icon name="terminal" cls="ic-16" />Full briefing</button>
        </div>

        {/* Signal tiles */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {signals.map((s, i) => (
            <div className="card tile" key={i} style={{ cursor: 'pointer' }} onClick={() => onAsk(`Analyze the market signal: ${s.ticker} ${s.val} — ${s.desc}`)}>
              <Label>{s.ticker}</Label>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                <span className="metric" style={{ fontSize: 20, color: toneColor(s.tone) }}>{s.val}</span>
                {s.ref && <div style={{ width: 60, height: 30, flex: 'none' }}><canvas ref={s.ref} style={{ width: '100%', height: '100%' }}></canvas></div>}
              </div>
              <span style={{ font: "var(--text-mono)", fontSize: 11, color: "var(--fg-3)", lineHeight: 1.4 }}>{s.desc}</span>
            </div>
          ))}
        </div>

        {/* Intelligence feed */}
        <div className="card" style={{ padding: "18px 20px", marginBottom: 16 }}>
          <SectionHead kicker="Competitive & regulatory" title="Intelligence feed" right={<span className="label">{intel.length} SIGNALS</span>} />
          <div>
            {intel.map((r, i) => (
              <div className="matrix-row" key={i} style={{ cursor: 'pointer', gridTemplateColumns: '1fr auto' }}
                onClick={() => onAsk(r.action)}>
                <span style={{ fontSize: 14, color: "var(--fg-1)", lineHeight: 1.4 }}>
                  <span style={{ color: "var(--fg-3)", font: "var(--text-mono)", fontSize: 11, textTransform: "uppercase", letterSpacing: ".1em", marginRight: 10 }}>{r.head}</span>
                  {r.body}
                </span>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <RiskPill level={r.level} />
                  <Icon name="arrow-right" cls="ic-14" style={{ color: 'var(--fg-4)' }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick analysis */}
        <div className="card" style={{ padding: '16px 20px' }}>
          <Label style={{ marginBottom: 12, display: 'block' }}>Quick analysis</Label>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {["Where are SaaS valuations heading?", "How does inflation affect our unit economics?", "What's the optimal window for our Series B?", "Analyze EUR strength impact on EU expansion"].map((q, i) => (
              <button key={i} className="btn btn-secondary" style={{ fontSize: 12 }} onClick={() => onAsk(q)}>{q}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { MarketsView });
