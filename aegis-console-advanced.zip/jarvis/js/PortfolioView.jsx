/* AEGIS Console — Portfolio intelligence with Nordnet/Avanza import */

function PortfolioView({ onAsk }) {
  useLucide();
  const chartRef = useRef(null);
  const pieRef = useRef(null);
  const [chartInst, setChartInst] = useState(null);
  const [pieInst, setPieInst] = useState(null);
  const [period, setPeriod] = useState('1Y');
  const [importOpen, setImportOpen] = useState(false);
  const [importText, setImportText] = useState('');
  const [lastSync, setLastSync] = useLocalStorage('aegis_portfolio_sync', null);
  const [customHoldings, setCustomHoldings] = useLocalStorage('aegis_holdings', null);
  const { apiKey, model } = useAegis();

  const defaultHoldings = [
    { name: "Nordnet Global", ticker: "NN:GLOBAL", value: 4820000, cost: 3900000, alloc: 31.2, trend: "up", change: "+23.6%", risk: "Medium", source: "Nordnet" },
    { name: "Avanza Auto", ticker: "AZ:AUTO", value: 3140000, cost: 2800000, alloc: 20.3, trend: "up", change: "+12.1%", risk: "High", source: "Avanza" },
    { name: "Fixed Income SEK", ticker: "FIL:SEK", value: 2900000, cost: 2900000, alloc: 18.8, trend: "muted", change: "+0.0%", risk: "Low", source: "Manual" },
    { name: "Real Assets REIT", ticker: "RART", value: 2240000, cost: 2500000, alloc: 14.5, trend: "down", change: "-10.4%", risk: "Medium", source: "Manual" },
    { name: "Nordnet Tillväxt", ticker: "NN:TILL", value: 1640000, cost: 1500000, alloc: 10.6, trend: "up", change: "+9.3%", risk: "High", source: "Nordnet" },
    { name: "Avanza Zero", ticker: "AZ:ZERO", value: 710000, cost: 710000, alloc: 4.6, trend: "up", change: "+5.1%", risk: "Low", source: "Avanza" },
  ];

  const holdings = customHoldings || defaultHoldings;
  const totalValue = holdings.reduce((s, h) => s + h.value, 0);
  const totalCost = holdings.reduce((s, h) => s + h.cost, 0);
  const totalGain = totalValue - totalCost;
  const totalGainPct = ((totalGain / totalCost) * 100).toFixed(1);

  function fmtM(v) {
    if (v >= 1e9) return `${(v/1e9).toFixed(2)}B kr`;
    if (v >= 1e6) return `${(v/1e6).toFixed(2)}M kr`;
    return `${(v/1e3).toFixed(0)}K kr`;
  }

  const periods = { '1M': 30, '3M': 90, '6M': 180, '1Y': 365, 'ALL': 730 };

  function generateData(days) {
    const pts = [];
    let v = totalCost;
    const now = Date.now();
    for (let i = days; i >= 0; i--) {
      v *= Math.exp(0.00035 + 0.003 * (Math.random() * 2 - 1));
      pts.push({ x: new Date(now - i * 864e5), y: Math.round(v) });
    }
    pts[pts.length - 1].y = totalValue;
    return pts;
  }

  useEffect(() => {
    if (!window.Chart || !chartRef.current) return;
    if (chartInst) chartInst.destroy();
    const data = generateData(periods[period]);
    const inst = new Chart(chartRef.current, {
      type: 'line',
      data: { datasets: [{ data, borderColor: '#5B9DD9', backgroundColor: 'rgba(91,157,217,0.07)', borderWidth: 2, pointRadius: 0, fill: true, tension: 0.35 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: {
          backgroundColor: '#161C26', borderColor: 'rgba(255,255,255,0.14)', borderWidth: 1,
          titleColor: '#6B7686', bodyColor: '#F2F5F8',
          callbacks: { label: ctx => ' ' + fmtM(ctx.parsed.y) },
        }},
        scales: {
          x: { type: 'time', time: { unit: period === '1M' ? 'day' : period === '1Y' || period === 'ALL' ? 'month' : 'week' }, ticks: { color: '#49525F', font: { family: 'IBM Plex Mono', size: 11 } }, grid: { color: 'rgba(255,255,255,0.05)' } },
          y: { ticks: { color: '#49525F', font: { family: 'IBM Plex Mono', size: 11 }, callback: v => fmtM(v) }, grid: { color: 'rgba(255,255,255,0.05)' } },
        },
      },
    });
    setChartInst(inst);
    return () => inst.destroy();
  }, [period, holdings]);

  useEffect(() => {
    if (!window.Chart || !pieRef.current) return;
    if (pieInst) pieInst.destroy();
    const colors = ['#5B9DD9','#3FC7C0','#2FB67C','#E0A53B','#E07B3B','#49525F','#7FB3E8','#A7B0BD'];
    const inst = new Chart(pieRef.current, {
      type: 'doughnut',
      data: { labels: holdings.map(h => h.name), datasets: [{ data: holdings.map(h => h.alloc), backgroundColor: colors, borderWidth: 0, hoverOffset: 6 }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: {
        backgroundColor: '#161C26', borderColor: 'rgba(255,255,255,0.14)', borderWidth: 1,
        titleColor: '#A7B0BD', bodyColor: '#F2F5F8', callbacks: { label: ctx => ` ${ctx.parsed.toFixed(1)}%` },
      }}, cutout: '68%' },
    });
    setPieInst(inst);
    return () => inst.destroy();
  }, [holdings]);

  /* Parse Nordnet/Avanza CSV export */
  const parseImport = () => {
    const lines = importText.trim().split('\n').filter(l => l.trim());
    if (!lines.length) { toast('No data entered', 'warn'); return; }

    // Try auto-detect format
    const header = lines[0].toLowerCase();
    let parsed = [];

    // Nordnet format: Typ;Namn;Antal;Kurs;Aktuellt värde;Anskaffningsvärde
    if (header.includes('anskaffningsvärde') || header.includes('nordnet')) {
      parsed = lines.slice(1).map(l => {
        const cols = l.split(';');
        if (cols.length < 6) return null;
        const name = cols[1]?.trim();
        const value = parseFloat(cols[4]?.replace(',', '.').replace(/\s/g, '')) || 0;
        const cost = parseFloat(cols[5]?.replace(',', '.').replace(/\s/g, '')) || value;
        return name && value ? { name, ticker: cols[0]?.trim() || name.slice(0,6), value, cost, source: 'Nordnet' } : null;
      }).filter(Boolean);
    }
    // Avanza format: Värdepapper,ISIN,Antal,Kurs,Marknadsvärde,Anskaffningsvärde
    else if (header.includes('värdepapper') || header.includes('avanza') || header.includes('isin')) {
      parsed = lines.slice(1).map(l => {
        const cols = l.split(',');
        if (cols.length < 6) return null;
        const name = cols[0]?.trim();
        const value = parseFloat(cols[4]?.replace(',', '.').replace(/\s/g, '')) || 0;
        const cost = parseFloat(cols[5]?.replace(',', '.').replace(/\s/g, '')) || value;
        return name && value ? { name, ticker: cols[1]?.trim() || name.slice(0,6), value, cost, source: 'Avanza' } : null;
      }).filter(Boolean);
    }
    // Generic CSV: Name,Value,Cost
    else {
      parsed = lines.slice(header.includes('name') || header.includes('namn') ? 1 : 0).map(l => {
        const cols = l.split(/[,;]/).map(c => c.trim().replace(/"/g, ''));
        if (cols.length < 2) return null;
        const name = cols[0];
        const value = parseFloat(cols[1]) || 0;
        const cost = parseFloat(cols[2]) || value;
        return name && value ? { name, ticker: name.slice(0,6).toUpperCase(), value, cost, source: 'Import' } : null;
      }).filter(Boolean);
    }

    if (!parsed.length) { toast('Could not parse data. Check format.', 'error'); return; }

    const total = parsed.reduce((s, h) => s + h.value, 0);
    const enriched = parsed.map(h => {
      const change = h.cost ? (((h.value - h.cost) / h.cost) * 100).toFixed(1) : '0.0';
      return {
        ...h,
        alloc: +((h.value / total) * 100).toFixed(1),
        change: (parseFloat(change) >= 0 ? '+' : '') + change + '%',
        trend: parseFloat(change) > 1 ? 'up' : parseFloat(change) < -1 ? 'down' : 'muted',
        risk: Math.abs(parseFloat(change)) > 20 ? 'High' : Math.abs(parseFloat(change)) > 8 ? 'Medium' : 'Low',
      };
    });

    setCustomHoldings(enriched);
    setLastSync(new Date().toISOString());
    setImportOpen(false);
    setImportText('');
    toast(`Imported ${enriched.length} positions`, 'success');
  };

  const requestAiAnalysis = async () => {
    const portfolioData = holdings.map(h => `${h.name}: ${fmtM(h.value)} (${h.change}, ${h.alloc}% allocation)`).join('\n');
    const prompt = `Analyze this portfolio:\n\nTotal value: ${fmtM(totalValue)}\nTotal return: ${totalGainPct}%\n\nPositions:\n${portfolioData}\n\nProvide: risk assessment, concentration risks, rebalancing recommendations, and what AEGIS recommends for portfolio strategy.`;
    onAsk(prompt);
  };

  const toneColor = t => t === 'up' ? 'var(--positive)' : t === 'down' ? 'var(--critical)' : 'var(--fg-3)';
  const sourceColor = s => s === 'Nordnet' ? 'var(--steel-400)' : s === 'Avanza' ? 'var(--cyan-400)' : 'var(--fg-4)';

  return (
    <div className="content scrolltrack">
      <div className="content-pad fadeup">
        {/* Header */}
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 22 }}>
          <div>
            <Label>Portfolio intelligence &middot; {new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</Label>
            <h1 style={{ font: "var(--text-h1)", margin: "10px 0 0", letterSpacing: "-0.01em" }}>Portfolio</h1>
            {lastSync && (
              <div style={{ font: 'var(--text-mono)', fontSize: 11, color: 'var(--fg-4)', marginTop: 4 }}>
                Last sync: {new Date(lastSync).toLocaleString()}
              </div>
            )}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary" onClick={() => setImportOpen(true)}>
              <Icon name="upload" cls="ic-16" />Import (Nordnet / Avanza)
            </button>
            {customHoldings && (
              <button className="btn btn-ghost" onClick={() => { setCustomHoldings(null); toast('Reset to demo data', 'info'); }}>
                <Icon name="refresh-cw" cls="ic-14" />Reset
              </button>
            )}
            <button className="btn btn-primary" onClick={requestAiAnalysis}>
              <Icon name="terminal" cls="ic-16" />AI analysis
            </button>
          </div>
        </div>

        {/* Import modal */}
        {importOpen && (
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', z: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50 }}
            onClick={() => setImportOpen(false)}>
            <div className="card" style={{ padding: '24px', width: 560, maxWidth: '90vw', maxHeight: '80vh', overflow: 'auto', boxShadow: 'var(--shadow-lg)' }}
              onClick={e => e.stopPropagation()}>
              <div style={{ marginBottom: 16 }}>
                <h3 style={{ font: 'var(--text-h4)', margin: '0 0 6px', color: 'var(--fg-1)' }}>Import portfolio data</h3>
                <p style={{ font: 'var(--text-body-sm)', color: 'var(--fg-3)', margin: 0, lineHeight: 1.5 }}>
                  Paste CSV data from <strong style={{ color: 'var(--steel-400)' }}>Nordnet</strong> (export via Depå → Exportera) or{' '}
                  <strong style={{ color: 'var(--cyan-400)' }}>Avanza</strong> (export via Min ekonomi → Exportera).
                  Also accepts generic CSV: <code style={{ font: 'var(--text-mono)', fontSize: 11 }}>Name,Value,CostBasis</code>
                </p>
              </div>
              <textarea
                value={importText}
                onChange={e => setImportText(e.target.value)}
                rows={12}
                placeholder={"Nordnet:\nTyp;Namn;Antal;Kurs;Aktuellt värde;Anskaffningsvärde\nAktiefond;Nordnet Global;100;482;48200;39000\n\nAvanza:\nVärdepapper,ISIN,Antal,Kurs,Marknadsvärde,Anskaffningsvärde\nAvanza Auto,SE123,200,157,31400,28000\n\nGeneric CSV:\nAsset Name,Current Value,Cost Basis\nMy Fund,500000,420000"}
                style={{ width: '100%', marginBottom: 12 }}
              />
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                <button className="btn btn-ghost" onClick={() => setImportOpen(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={parseImport} disabled={!importText.trim()}>
                  <Icon name="upload" cls="ic-14" />Import
                </button>
              </div>
            </div>
          </div>
        )}

        {/* KPI tiles */}
        <div className="grid-metrics" style={{ marginBottom: 24 }}>
          <MetricTile label="Total value" value={fmtM(totalValue)} delta={`▲ ${totalGainPct}% total return`} tone="up" />
          <MetricTile label="Unrealized gain" value={fmtM(totalGain)} delta={`vs ${fmtM(totalCost)} cost basis`} tone="up" />
          <MetricTile label="Positions" value={holdings.length} delta={`${holdings.filter(h=>h.source==='Nordnet').length} Nordnet · ${holdings.filter(h=>h.source==='Avanza').length} Avanza`} tone="muted" />
          <MetricTile label="Risk score" value="6.2" unit="/10" delta="Moderate — review allocation" tone="warn" onClick={() => onAsk("Analyze my portfolio risk score of 6.2/10 — what's driving it and how can I reduce risk without sacrificing return?")} />
        </div>

        {/* Chart + Allocation */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 16, marginBottom: 20 }}>
          <div className="card" style={{ padding: '18px 20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div>
                <Label>Performance</Label>
                <h3 style={{ font: 'var(--text-h4)', margin: '4px 0 0', color: 'var(--fg-1)' }}>Portfolio value over time</h3>
              </div>
              <div style={{ display: 'flex', gap: 4 }}>
                {Object.keys(periods).map(p => (
                  <button key={p} className={`btn ${period === p ? 'btn-secondary' : 'btn-ghost'}`}
                    style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => setPeriod(p)}>{p}</button>
                ))}
              </div>
            </div>
            <div style={{ height: 200 }}><canvas ref={chartRef}></canvas></div>
          </div>

          <div className="card" style={{ padding: '18px 20px' }}>
            <Label>Allocation</Label>
            <h3 style={{ font: 'var(--text-h4)', margin: '4px 0 14px', color: 'var(--fg-1)' }}>By position</h3>
            <div style={{ height: 140, marginBottom: 12 }}><canvas ref={pieRef}></canvas></div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              {holdings.slice(0, 5).map((h, i) => {
                const colors = ['#5B9DD9','#3FC7C0','#2FB67C','#E0A53B','#E07B3B','#49525F'];
                return (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--fg-2)' }}>
                    <span style={{ width: 8, height: 8, borderRadius: 2, background: colors[i], flex: 'none' }}></span>
                    <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{h.name}</span>
                    <span style={{ font: 'var(--text-mono)', fontSize: 11, color: 'var(--fg-3)' }}>{h.alloc}%</span>
                  </div>
                );
              })}
              {holdings.length > 5 && <div style={{ fontSize: 11, color: 'var(--fg-4)', marginTop: 2 }}>+{holdings.length - 5} more</div>}
            </div>
          </div>
        </div>

        {/* Holdings table */}
        <div className="card" style={{ overflow: 'hidden', marginBottom: 16 }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <Label>Positions</Label>
              <h3 style={{ font: 'var(--text-h4)', margin: '4px 0 0', color: 'var(--fg-1)' }}>Holdings</h3>
            </div>
            <span className="label">{holdings.length} POSITIONS</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr auto auto', padding: '8px 20px', borderBottom: '1px solid var(--line)' }}>
            {['Asset', 'Value', 'Cost', 'Return', 'Alloc', 'Source', 'Risk'].map(h => (
              <span key={h} className="label" style={{ fontSize: 10 }}>{h}</span>
            ))}
          </div>
          {holdings.map((h, i) => (
            <div key={i}
              style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr auto auto', padding: '12px 20px', borderBottom: i < holdings.length - 1 ? '1px solid var(--line)' : 'none', alignItems: 'center', cursor: 'pointer', transition: 'background .14s' }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-raised)'}
              onMouseLeave={e => e.currentTarget.style.background = ''}
              onClick={() => onAsk(`Analyze my position in ${h.name}: current value ${fmtM(h.value)}, return ${h.change}, allocation ${h.alloc}%. Should I hold, add, or trim?`)}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--fg-1)' }}>{h.name}</div>
                <div style={{ font: 'var(--text-mono)', fontSize: 11, color: 'var(--fg-4)', marginTop: 2 }}>{h.ticker}</div>
              </div>
              <span style={{ font: 'var(--text-mono)', fontSize: 13 }}>{fmtM(h.value)}</span>
              <span style={{ font: 'var(--text-mono)', fontSize: 13, color: 'var(--fg-3)' }}>{fmtM(h.cost)}</span>
              <span style={{ font: 'var(--text-mono)', fontSize: 13, color: toneColor(h.trend) }}>{h.change}</span>
              <span style={{ font: 'var(--text-mono)', fontSize: 13, color: 'var(--fg-3)' }}>{h.alloc}%</span>
              <span style={{ font: 'var(--text-mono)', fontSize: 10, color: sourceColor(h.source), letterSpacing: '.05em' }}>{(h.source || '').toUpperCase()}</span>
              <RiskPill level={h.risk} />
            </div>
          ))}
        </div>

        {/* Monthly refresh note */}
        <div className="card" style={{ padding: '14px 18px', borderColor: 'rgba(91,157,217,0.2)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Icon name="refresh-cw" cls="ic-16" style={{ color: 'var(--steel-400)' }} />
            <div style={{ flex: 1 }}>
              <span style={{ font: 'var(--text-mono)', fontSize: 11, color: 'var(--steel-400)' }}>MONTHLY DATA REFRESH</span>
              <p style={{ font: 'var(--text-body-sm)', color: 'var(--fg-3)', margin: '3px 0 0' }}>
                Export your holdings from Nordnet (Depå → Exportera) or Avanza (Min ekonomi → Exportera) monthly and paste via the Import button to keep AEGIS's portfolio analysis current.
              </p>
            </div>
            <button className="btn btn-secondary" style={{ fontSize: 12, flexShrink: 0 }} onClick={() => setImportOpen(true)}>
              <Icon name="upload" cls="ic-14" />Sync now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { PortfolioView });
