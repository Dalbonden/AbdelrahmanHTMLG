/* AEGIS Console — Security intelligence view */
function SecurityView({ onAsk }) {
  useLucide();
  const [activeFilter, setActiveFilter] = React.useState("All");

  const threats = [
    { item: "Secrets rotation overdue — 3 production services", level: "Critical", age: "14 days", category: "Credentials", action: "How do I safely rotate secrets in production without downtime across 3 services?" },
    { item: "Unpatched CVE-2024-3094 (xz-utils) on 2 hosts", level: "High", age: "7 days", category: "Vulnerabilities", action: "What is CVE-2024-3094 and what's the fastest safe remediation path for production hosts?" },
    { item: "Admin account without MFA — 1 user", level: "High", age: "3 days", category: "Access", action: "What are the risks of an admin account without MFA and how should we enforce it?" },
    { item: "S3 bucket with public-read ACL (non-CDN)", level: "Medium", age: "21 days", category: "Cloud", action: "Analyze the risk of a public-read S3 bucket and give me remediation steps" },
    { item: "Stale API keys in CI environment variables", level: "Medium", age: "45 days", category: "Credentials", action: "How should we audit and rotate stale API keys in CI/CD environment variables?" },
    { item: "SSL cert expiry in 18 days — staging.app", level: "Low", age: "Today", category: "Infrastructure", action: "What's the process to renew an SSL certificate and what happens if it expires?" },
    { item: "Dependency audit: 4 packages with known CVEs", level: "Medium", age: "2 days", category: "Vulnerabilities", action: "How do I assess and remediate 4 npm packages flagged with CVEs in production?" },
    { item: "Unused IAM role with broad S3 permissions", level: "Low", age: "30 days", category: "Access", action: "What's the security risk of unused IAM roles and how do I safely remove them?" },
  ];

  const categories = ["All", "Credentials", "Vulnerabilities", "Access", "Cloud", "Infrastructure"];
  const filtered = activeFilter === "All" ? threats : threats.filter(t => t.category === activeFilter);

  const counts = { Critical: 0, High: 0, Medium: 0, Low: 0 };
  threats.forEach(t => counts[t.level]++);

  const scoreColor = s => s >= 80 ? "var(--positive)" : s >= 60 ? "var(--warning)" : "var(--critical)";
  const secScore = 61;

  const controls = [
    { name: "Encryption at rest", status: "Pass", icon: "shield-check" },
    { name: "Encryption in transit (TLS 1.3)", status: "Pass", icon: "lock" },
    { name: "WAF / DDoS protection", status: "Pass", icon: "shield" },
    { name: "Secrets manager (Vault)", status: "Warn", icon: "key" },
    { name: "Automated dependency scanning", status: "Fail", icon: "scan" },
    { name: "SIEM / log aggregation", status: "Warn", icon: "activity" },
  ];

  const statusColor = s => s === "Pass" ? "var(--positive)" : s === "Warn" ? "var(--warning)" : "var(--critical)";

  return (
    <div className="content scrolltrack">
      <div className="content-pad fadeup">
        {/* Header */}
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 22 }}>
          <div>
            <Label>Security posture &middot; {new Date().toLocaleDateString("en-US", { month: "long", day: "numeric" })}</Label>
            <h1 style={{ font: "var(--text-h1)", margin: "10px 0 0", letterSpacing: "-0.01em" }}>Security</h1>
          </div>
          <button className="btn btn-primary" onClick={() => onAsk("Give me a comprehensive security briefing: current threat landscape, our most critical vulnerabilities, remediation priorities, and a 30-day action plan")}><Icon name="terminal" cls="ic-16" />Full audit</button>
        </div>

        {/* Security score + severity tiles */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          <div className="card tile" style={{ cursor: "pointer" }} onClick={() => onAsk(`Our security posture score is ${secScore}/100. What does this mean and what are the highest-impact improvements I can make?`)}>
            <Label>Security score</Label>
            <span className="metric" style={{ fontSize: 32, color: scoreColor(secScore) }}>{secScore}</span>
            <span style={{ font: "var(--text-mono)", fontSize: 11, color: "var(--fg-3)" }}>/ 100 &middot; Needs work</span>
          </div>
          {[["Critical", "var(--critical)"], ["High", "var(--orange-400,#E07B3B)"], ["Medium", "var(--warning)"], ["Low", "var(--positive)"]].map(([lvl, col]) => (
            <div className="card tile" key={lvl} style={{ cursor: "pointer" }} onClick={() => onAsk(`Analyze all ${lvl.toLowerCase()} severity security findings and give me a prioritized remediation plan`)}>
              <Label style={{ color: col }}>{lvl}</Label>
              <span className="metric" style={{ fontSize: 28, color: "var(--fg-1)" }}>{counts[lvl]}</span>
              <span style={{ font: "var(--text-mono)", fontSize: 12, color: "var(--fg-3)" }}>finding{counts[lvl] !== 1 ? "s" : ""}</span>
            </div>
          ))}
        </div>

        {/* Threat register */}
        <div className="card" style={{ padding: "18px 20px", marginBottom: 16 }}>
          <SectionHead kicker="Active findings" title="Threat register" right={<span className="label">{threats.length} OPEN</span>} />

          {/* Category filter */}
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
            {categories.map(cat => (
              <button key={cat} className={`btn ${activeFilter === cat ? "btn-primary" : "btn-ghost"}`}
                style={{ fontSize: 11, padding: "3px 10px" }}
                onClick={() => setActiveFilter(cat)}>{cat}</button>
            ))}
          </div>

          <div>
            {filtered.map((r, i) => (
              <div className="matrix-row" key={i} style={{ cursor: "pointer", gridTemplateColumns: "auto 1fr auto auto" }}
                onClick={() => onAsk(r.action)}>
                <span className="label" style={{ color: "var(--fg-4)", minWidth: 90, fontSize: 10 }}>{r.category}</span>
                <span style={{ fontSize: 14, color: "var(--fg-1)", lineHeight: 1.4 }}>
                  {r.item}
                  <span style={{ color: "var(--fg-4)", marginLeft: 10, fontSize: 12 }}>&middot; {r.age} ago</span>
                </span>
                <RiskPill level={r.level} />
                <Icon name="arrow-right" cls="ic-14" style={{ color: "var(--fg-4)" }} />
              </div>
            ))}
          </div>
        </div>

        {/* Security controls */}
        <div className="card" style={{ padding: "18px 20px", marginBottom: 16 }}>
          <SectionHead kicker="Control framework" title="Security controls" right={
            <span className="label">{controls.filter(c => c.status === "Pass").length}/{controls.length} PASSING</span>
          } />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {controls.map((c, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px",
                background: "var(--bg-raised)", borderRadius: 6, cursor: "pointer", border: "1px solid var(--line)" }}
                onClick={() => onAsk(`Explain the ${c.name} control status "${c.status}" and what I need to do to get it to Pass`)}>
                <Icon name={c.icon} cls="ic-16" style={{ color: statusColor(c.status), flex: "none" }} />
                <span style={{ fontSize: 13, color: "var(--fg-1)", flex: 1 }}>{c.name}</span>
                <span style={{ font: "var(--text-mono)", fontSize: 11, color: statusColor(c.status) }}>{c.status.toUpperCase()}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick actions */}
        <div className="card" style={{ padding: "16px 20px" }}>
          <Label style={{ marginBottom: 12, display: "block" }}>Quick analysis</Label>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {[
              "How do I implement a zero-trust architecture?",
              "Write a secrets rotation runbook for production",
              "What's our biggest security exposure right now?",
              "How do I set up automated vulnerability scanning?",
            ].map((q, i) => (
              <button key={i} className="btn btn-secondary" style={{ fontSize: 12 }} onClick={() => onAsk(q)}>{q}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { SecurityView });
