/* AEGIS Console — Settings view */

function SettingsView() {
  useLucide();
  const { apiKey, setApiKey, model, setModel, userName, setUserName } = useAegis();
  const [keyInput, setKeyInput] = useState(apiKey || '');
  const [showKey, setShowKey] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [systemPrompt, setSystemPrompt] = useState(AEGIS_SYSTEM_PROMPT);
  const [promptEdited, setPromptEdited] = useState(false);

  const saveKey = () => {
    setApiKey(keyInput.trim());
    toast('API key saved', 'success');
    setTestResult(null);
  };

  const testKey = async () => {
    if (!keyInput.trim()) { toast('Enter an API key first', 'warn'); return; }
    setTesting(true);
    setTestResult(null);
    try {
      await callAegis([{ role: 'user', content: 'Reply with exactly: {"verdict":"BUILD","confidence":"High","summary":"API key verified.","findings":["Connection successful"],"analysis":[{"head":"Technical","body":"API reachable."}],"risks":[],"recommendations":["Proceed"],"next":["Start"]}' }], keyInput.trim(), model);
      setTestResult('ok');
      setApiKey(keyInput.trim());
      toast('API key verified and saved', 'success');
    } catch (err) {
      setTestResult('err');
      toast('Test failed: ' + err.message, 'error');
    } finally {
      setTesting(false);
    }
  };

  const exportSettings = () => {
    const data = JSON.stringify({ model, userName }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'aegis-settings.json'; a.click();
    URL.revokeObjectURL(url);
  };

  const clearAll = () => {
    if (!confirm('Clear all stored data including API key and conversation history?')) return;
    localStorage.clear();
    toast('All data cleared. Reload to reset.', 'info');
  };

  const models = [
    { id: 'claude-opus-4-8', label: 'Claude Opus 4.8 — Most capable' },
    { id: 'claude-sonnet-4-6', label: 'Claude Sonnet 4.6 — Recommended' },
    { id: 'claude-haiku-4-5-20251001', label: 'Claude Haiku 4.5 — Fast & efficient' },
  ];

  return (
    <div className="content scrolltrack">
      <div className="content-pad fadeup">
        <div style={{ marginBottom: 28 }}>
          <Label>System configuration</Label>
          <h1 style={{ font: "var(--text-h1)", margin: "10px 0 0", letterSpacing: "-0.01em" }}>Settings</h1>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 28, maxWidth: 680 }}>

          {/* API Key */}
          <section className="card" style={{ padding: '22px 24px' }}>
            <div style={{ marginBottom: 18 }}>
              <h3 style={{ font: 'var(--text-h4)', margin: '0 0 4px', color: 'var(--fg-1)' }}>Anthropic API key</h3>
              <p style={{ font: 'var(--text-body-sm)', color: 'var(--fg-3)', margin: 0 }}>
                Required to enable real AI analysis. Stored in your browser's localStorage — never sent anywhere except Anthropic's API.
              </p>
            </div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              <div style={{ flex: 1, position: 'relative' }}>
                <input
                  type={showKey ? 'text' : 'password'}
                  value={keyInput}
                  onChange={e => { setKeyInput(e.target.value); setTestResult(null); }}
                  placeholder="sk-ant-..."
                  style={{ width: '100%', fontFamily: 'var(--font-mono)', fontSize: 13, paddingRight: 40 }}
                />
                <button onClick={() => setShowKey(v => !v)} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fg-3)', display: 'flex' }}>
                  <Icon name={showKey ? 'eye-off' : 'eye'} cls="ic-16" />
                </button>
              </div>
              <button className="btn btn-secondary" onClick={testKey} disabled={testing || !keyInput.trim()}>
                {testing ? <Spinner size={14} /> : <Icon name="zap" cls="ic-14" />}
                {testing ? 'Testing' : 'Test'}
              </button>
              <button className="btn btn-primary" onClick={saveKey} disabled={!keyInput.trim()}>Save</button>
            </div>
            {testResult === 'ok' && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, font: 'var(--text-mono)', fontSize: 11, color: 'var(--positive)' }}>
                <Icon name="check-circle" cls="ic-14" />KEY VERIFIED — CONNECTED
              </div>
            )}
            {testResult === 'err' && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, font: 'var(--text-mono)', fontSize: 11, color: 'var(--critical)' }}>
                <Icon name="x-circle" cls="ic-14" />VERIFICATION FAILED — CHECK KEY AND PERMISSIONS
              </div>
            )}
            {apiKey && !testResult && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, font: 'var(--text-mono)', fontSize: 11, color: 'var(--fg-4)' }}>
                <Icon name="check" cls="ic-14" />KEY SAVED · {apiKey.slice(0,10)}...
              </div>
            )}
          </section>

          {/* Model */}
          <section className="card" style={{ padding: '22px 24px' }}>
            <div style={{ marginBottom: 18 }}>
              <h3 style={{ font: 'var(--text-h4)', margin: '0 0 4px', color: 'var(--fg-1)' }}>Intelligence model</h3>
              <p style={{ font: 'var(--text-body-sm)', color: 'var(--fg-3)', margin: 0 }}>Model used for all AEGIS analyses. Sonnet recommended for balance of depth and speed.</p>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {models.map(m => (
                <label key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderRadius: 'var(--r-md)', border: `1px solid ${model === m.id ? 'var(--accent-line)' : 'var(--line)'}`, background: model === m.id ? 'var(--accent-soft)' : 'var(--bg-inset)', cursor: 'pointer', transition: 'all .14s' }}>
                  <input type="radio" name="model" value={m.id} checked={model === m.id} onChange={() => { setModel(m.id); toast(`Model set to ${m.id}`, 'info'); }} style={{ accentColor: 'var(--accent)' }} />
                  <div>
                    <div style={{ font: 'var(--text-mono)', fontSize: 12, color: model === m.id ? 'var(--accent)' : 'var(--fg-1)', letterSpacing: '.02em' }}>{m.id}</div>
                    <div style={{ fontSize: 12, color: 'var(--fg-3)', marginTop: 2 }}>{m.label.split('—')[1]}</div>
                  </div>
                </label>
              ))}
            </div>
          </section>

          {/* User profile */}
          <section className="card" style={{ padding: '22px 24px' }}>
            <div style={{ marginBottom: 18 }}>
              <h3 style={{ font: 'var(--text-h4)', margin: '0 0 4px', color: 'var(--fg-1)' }}>Principal profile</h3>
              <p style={{ font: 'var(--text-body-sm)', color: 'var(--fg-3)', margin: 0 }}>Displayed in the navigation rail. AEGIS addresses you as the principal.</p>
            </div>
            <div className="field">
              <label className="field-label">Name</label>
              <input type="text" value={userName || ''} onChange={e => setUserName(e.target.value)} placeholder="Your name" style={{ maxWidth: 300 }} />
            </div>
          </section>

          {/* System prompt */}
          <section className="card" style={{ padding: '22px 24px' }}>
            <div style={{ marginBottom: 18, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
              <div>
                <h3 style={{ font: 'var(--text-h4)', margin: '0 0 4px', color: 'var(--fg-1)' }}>AEGIS system prompt</h3>
                <p style={{ font: 'var(--text-body-sm)', color: 'var(--fg-3)', margin: 0 }}>The operating instructions sent with every analysis request. Edit to specialize AEGIS for your context.</p>
              </div>
              {promptEdited && (
                <button className="btn btn-ghost" style={{ fontSize: 12, flexShrink: 0 }} onClick={() => { setSystemPrompt(AEGIS_SYSTEM_PROMPT); setPromptEdited(false); toast('Reset to default', 'info'); }}>
                  Reset
                </button>
              )}
            </div>
            <textarea
              value={systemPrompt}
              onChange={e => { setSystemPrompt(e.target.value); setPromptEdited(true); }}
              rows={12}
              style={{ width: '100%' }}
            />
            {promptEdited && (
              <button className="btn btn-primary" style={{ marginTop: 10, fontSize: 13 }} onClick={() => {
                window._aegisSetSystemPrompt && window._aegisSetSystemPrompt(systemPrompt);
                setPromptEdited(false);
                toast('System prompt updated', 'success');
              }}>Save system prompt</button>
            )}
          </section>

          {/* Keyboard shortcuts */}
          <section className="card" style={{ padding: '22px 24px' }}>
            <h3 style={{ font: 'var(--text-h4)', margin: '0 0 16px', color: 'var(--fg-1)' }}>Keyboard shortcuts</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['Open command palette', 'Ctrl+K / ⌘K'],
                ['New analysis', 'Ctrl+Shift+N'],
                ['Go to Briefing', 'Ctrl+1'],
                ['Go to Ask AEGIS', 'Ctrl+2'],
                ['Go to Analyses', 'Ctrl+3'],
                ['Send message (chat)', 'Enter'],
                ['New line (chat)', 'Shift+Enter'],
                ['Clear conversation', 'Ctrl+L'],
              ].map(([label, key]) => (
                <div key={label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 13, color: 'var(--fg-2)' }}>
                  <span>{label}</span>
                  <kbd>{key}</kbd>
                </div>
              ))}
            </div>
          </section>

          {/* Danger zone */}
          <section className="card" style={{ padding: '22px 24px', borderColor: 'rgba(224,78,54,0.2)' }}>
            <h3 style={{ font: 'var(--text-h4)', margin: '0 0 16px', color: 'var(--fg-1)' }}>Data & privacy</h3>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <button className="btn btn-secondary" onClick={exportSettings}><Icon name="download" cls="ic-14" />Export settings</button>
              <button className="btn btn-secondary" style={{ color: 'var(--critical)', borderColor: 'rgba(224,78,54,0.3)' }} onClick={clearAll}>
                <Icon name="trash-2" cls="ic-14" />Clear all data
              </button>
            </div>
            <p style={{ font: 'var(--text-body-sm)', color: 'var(--fg-4)', margin: '12px 0 0' }}>
              All data is stored locally in your browser. No data is sent to any server except Anthropic's API when you run an analysis.
            </p>
          </section>

        </div>
      </div>
    </div>
  );
}
Object.assign(window, { SettingsView });
