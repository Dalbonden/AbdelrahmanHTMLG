/* AEGIS Console — left navigation rail */
function Sidebar({ active, onNav }) {
  useLucide();
  const { userName } = useAegis();

  const nav = [
    { section: "Operate" },
    { id: "briefing",    label: "Briefing",    icon: "layout-dashboard" },
    { id: "ask",         label: "Ask AEGIS",   icon: "terminal" },
    { id: "analyses",    label: "Analyses",    icon: "file-text", badge: "3" },
    { section: "Intelligence" },
    { id: "markets",     label: "Markets",     icon: "line-chart" },
    { id: "portfolio",   label: "Portfolio",   icon: "briefcase" },
    { id: "security",    label: "Security",    icon: "shield-check", badge: "1", badgeColor: "var(--critical)", badgeBg: "var(--critical-soft)" },
    { section: "System" },
    { id: "automations", label: "Automations", icon: "git-branch" },
    { id: "settings",    label: "Settings",    icon: "settings" },
  ];

  const initials = (userName || "JD").split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  const displayName = userName || "J. Dalbonden";

  return (
    <aside className="rail">
      <div className="rail-top">
        <span className="rail-logo"><img src="assets/logo-mark.svg" width="30" height="30" alt="AEGIS" /></span>
        <span className="rail-word">AEGIS</span>
      </div>
      <div className="rail-status"><span className="live-dot"></span>SYSTEM ONLINE &middot; v2.4</div>
      <nav className="nav scrolltrack">
        {nav.map((n, i) => n.section
          ? <div className="nav-section" key={"s" + i}>{n.section}</div>
          : (
            <div key={n.id} className={"nav-item" + (active === n.id ? " active" : "")} onClick={() => onNav(n.id)}>
              <Icon name={n.icon} cls="ic-18" />
              <span>{n.label}</span>
              {n.badge && (
                <span className="badge" style={n.badgeColor ? { background: n.badgeBg, color: n.badgeColor } : {}}>{n.badge}</span>
              )}
            </div>
          ))}
      </nav>
      <div className="rail-user" style={{ cursor: 'pointer' }} onClick={() => onNav('settings')}>
        <div className="avatar">{initials}</div>
        <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.3, flex: 1, minWidth: 0 }}>
          <span style={{ fontSize: 13, color: "var(--fg-1)", overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{displayName}</span>
          <span className="label" style={{ fontSize: 10 }}>PRINCIPAL</span>
        </div>
        <Icon name="settings" cls="ic-14" style={{ color: 'var(--fg-4)' }} />
      </div>
    </aside>
  );
}
Object.assign(window, { Sidebar });
