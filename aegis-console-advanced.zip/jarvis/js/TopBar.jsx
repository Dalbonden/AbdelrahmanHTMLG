/* AEGIS Console — top bar with live clock and search */
function TopBar({ crumb, title, onSearch }) {
  useLucide();
  const { apiKey } = useAegis();
  const [clock, setClock] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const tick = () => {
      const d = new Date();
      const p = (n) => String(n).padStart(2, "0");
      setClock(`${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())} UTC`);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <header className="topbar">
      <span className="crumb">{crumb}</span>
      <h1>{title}</h1>
      <div className="topbar-search" style={{ cursor: 'pointer' }} onClick={onSearch}>
        <Icon name="search" cls="ic-16" />
        <span>Search or jump to…</span>
        <kbd style={{ marginLeft: 'auto' }}>⌘K</kbd>
      </div>
      <div className="topbar-meta">
        {apiKey
          ? <span style={{ display: "flex", alignItems: "center", gap: 7, color: "var(--positive)" }}><span className="dot" style={{ background: "var(--positive)" }}></span>AI READY</span>
          : <span style={{ display: "flex", alignItems: "center", gap: 7, color: "var(--fg-4)" }}><span className="dot" style={{ background: "var(--fg-4)" }}></span>NO KEY</span>
        }
        <span style={{ display: "flex", alignItems: "center", gap: 7, color: "var(--accent)" }}><span className="dot" style={{ background: "var(--accent)" }}></span>LIVE</span>
        <span>{clock}</span>
      </div>
    </header>
  );
}
Object.assign(window, { TopBar });
