/* AEGIS Console — shared primitives & utilities */
const { useState, useEffect, useRef, useCallback, useContext, createContext } = React;

/* ---- Global context ---- */
const AegisContext = createContext({});
function useAegis() { return useContext(AegisContext); }

/* ---- localStorage hook ---- */
function useLocalStorage(key, defaultVal) {
  const [val, setVal] = useState(() => {
    try { const s = localStorage.getItem(key); return s != null ? JSON.parse(s) : defaultVal; }
    catch { return defaultVal; }
  });
  const set = useCallback(v => {
    setVal(v);
    try { localStorage.setItem(key, JSON.stringify(v)); } catch {}
  }, [key]);
  return [val, set];
}

/* ---- Toast system ---- */
let toastId = 0;
let addToast = () => {};
function ToastProvider() {
  const [toasts, setToasts] = useState([]);
  addToast = (msg, type = 'info') => {
    const id = ++toastId;
    setToasts(t => [...t, { id, msg, type }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3500);
  };
  const icons = { info: 'info', success: 'check-circle', error: 'alert-circle', warn: 'alert-triangle' };
  const colors = { info: 'var(--steel-400)', success: 'var(--positive)', error: 'var(--critical)', warn: 'var(--warning)' };
  if (!toasts.length) return null;
  return (
    <div className="toast-stack">
      {toasts.map(t => (
        <div key={t.id} className="toast">
          <i data-lucide={icons[t.type]} className="lucide ic-16" style={{ color: colors[t.type], flex: 'none' }}></i>
          {t.msg}
        </div>
      ))}
    </div>
  );
}
function toast(msg, type) { addToast(msg, type); }

/* ---- Icon ---- */
function Icon({ name, cls = "" }) {
  return <i data-lucide={name} className={"lucide " + cls}></i>;
}
function useLucide() {
  useEffect(() => { if (window.lucide) window.lucide.createIcons(); });
}

/* ---- Typography ---- */
function Label({ children, style }) {
  return <span className="label" style={style}>{children}</span>;
}

/* ---- Risk / Verdict badges ---- */
const RISK = {
  Low:      { c: "var(--positive)",   bg: "var(--positive-soft)" },
  Medium:   { c: "var(--warning)",    bg: "var(--warning-soft)" },
  High:     { c: "var(--orange-400)", bg: "rgba(224,123,59,.13)" },
  Critical: { c: "var(--critical)",   bg: "var(--critical-soft)" },
};
function RiskPill({ level }) {
  const r = RISK[level] || RISK.Low;
  return <span className="pill" style={{ background: r.bg, color: r.c }}><span className="dot"></span>{level}</span>;
}

const VERDICT = {
  BUILD:            { c: "var(--positive)",   bg: "var(--positive-soft)" },
  "VALIDATE FIRST": { c: "var(--warning)",    bg: "var(--warning-soft)" },
  PIVOT:            { c: "var(--steel-300)",   bg: "var(--data-soft)" },
  REJECT:           { c: "var(--critical)",   bg: "var(--critical-soft)" },
};
function Verdict({ label }) {
  if (!label) return null;
  const v = VERDICT[label] || VERDICT.BUILD;
  return <span style={{ font: "600 13px/1 var(--font-sans)", padding: "6px 13px", borderRadius: "var(--r-sm)", background: v.bg, color: v.c, letterSpacing: ".02em", whiteSpace: 'nowrap' }}>{label}</span>;
}
function Confidence({ level }) {
  if (!level) return null;
  return <span className="pill" style={{ background: "var(--data-soft)", color: "var(--steel-300)" }}>Confidence: {level}</span>;
}

/* ---- Metric tile ---- */
function MetricTile({ label, value, delta, tone = "muted", unit, onClick }) {
  const toneColor = { up: "var(--positive)", warn: "var(--warning)", down: "var(--critical)", muted: "var(--fg-3)" }[tone];
  const arrow = tone === "up" ? "▲" : tone === "down" ? "▼" : "";
  return (
    <div className="card tile" style={onClick ? { cursor: 'pointer' } : {}} onClick={onClick}>
      <Label>{label}</Label>
      <span className="metric">{value}{unit && <span style={{ fontSize: 15, color: "var(--fg-3)" }}> {unit}</span>}</span>
      <span style={{ font: "var(--text-mono)", fontSize: 12, color: toneColor }}>{arrow && arrow + " "}{delta}</span>
    </div>
  );
}

/* ---- Section header ---- */
function SectionHead({ kicker, title, right }) {
  return (
    <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 14 }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {kicker && <Label>{kicker}</Label>}
        <h2 style={{ font: "var(--text-h3)", margin: 0, color: "var(--fg-1)" }}>{title}</h2>
      </div>
      {right}
    </div>
  );
}

/* ---- Spinner ---- */
function Spinner({ size = 20 }) {
  useEffect(() => { if (window.lucide) window.lucide.createIcons(); });
  return <i data-lucide="loader" className="lucide" style={{ width: size, height: size, animation: 'spin 1s linear infinite' }}></i>;
}

/* ---- Copy button ---- */
function CopyBtn({ text, label = "Copy" }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  };
  useEffect(() => { if (window.lucide) window.lucide.createIcons(); });
  return (
    <button className="btn btn-ghost" style={{ fontSize: 12 }} onClick={copy}>
      <i data-lucide={copied ? "check" : "copy"} className="lucide ic-14"></i>
      {copied ? "Copied" : label}
    </button>
  );
}

/* ---- AEGIS system prompt ---- */
const AEGIS_SYSTEM_PROMPT = `You are AEGIS — an Executive Intelligence System operating as a compressed multidisciplinary executive team: founder, CEO, COO, CTO, chief economist, investment analyst, security architect, and financial controller.

Your purpose: act as a strategic partner, technical advisor, business operator, analyst, and execution engine. You maximize long-term value creation while minimizing risk, waste, technical debt, and poor decision-making.

Voice: Brutally analytical but professional. Truth over agreement. No fake certainty. Executive-level, decisive, structured. Never hyped, never motivational. Dense with signal, zero fluff. First-person as "AEGIS." Address the user as "you" (the principal).

ALWAYS respond with ONLY a valid JSON object. No markdown. No prose outside the JSON. No code fences.

Required structure:
{
  "verdict": "BUILD" | "VALIDATE FIRST" | "PIVOT" | "REJECT",
  "confidence": "Very Low" | "Low" | "Moderate" | "High" | "Very High",
  "summary": "1-3 sentence executive summary. Dense. Quantified where possible. No fluff.",
  "findings": ["Finding with data/evidence", "..."],
  "analysis": [
    {"head": "Strategic", "body": "..."},
    {"head": "Financial", "body": "..."},
    {"head": "Technical", "body": "..."},
    {"head": "Operational", "body": "..."}
  ],
  "risks": [
    {"item": "Risk description", "mitigation": "Specific mitigation", "level": "Critical" | "High" | "Medium" | "Low"}
  ],
  "recommendations": ["Specific, actionable recommendation", "..."],
  "next": ["Concrete next step", "..."]
}

Rules:
- Quantify everything. Show deltas with direction arrows (▲ ▼).
- Always include at least 3 findings, 2-4 risks, 3 recommendations, 4 next steps.
- Verdicts: BUILD = confident, build/proceed; VALIDATE FIRST = real signal but needs validation before commitment; PIVOT = directional change needed; REJECT = clear no.
- Risks always rated Critical/High/Medium/Low with a concrete mitigation.
- No emoji. No motivational language. No filler.
- If the question is not a business/strategic decision, still provide the best analysis you can in this format. For technical, personal, or open-ended questions, adapt the framework to the context.`;

/* ---- Call Claude API ---- */
async function callAegis(messages, apiKey, model, onChunk) {
  const streaming = typeof onChunk === 'function';
  const body = {
    model: model || 'claude-sonnet-4-6',
    max_tokens: 4096,
    system: AEGIS_SYSTEM_PROMPT,
    messages,
    stream: streaming,
  };

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `API error ${res.status}`);
  }

  if (!streaming) {
    const data = await res.json();
    return data.content[0].text;
  }

  // Streaming
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let accumulated = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = decoder.decode(value, { stream: true });
    for (const line of chunk.split('\n')) {
      if (!line.startsWith('data: ')) continue;
      const raw = line.slice(6).trim();
      if (raw === '[DONE]') break;
      try {
        const evt = JSON.parse(raw);
        if (evt.type === 'content_block_delta' && evt.delta?.text) {
          accumulated += evt.delta.text;
          onChunk(accumulated);
        }
      } catch {}
    }
  }
  return accumulated;
}

/* ---- Parse AEGIS JSON response ---- */
function parseAegisResponse(text) {
  // Try direct parse
  try { return JSON.parse(text); } catch {}
  // Try extract from code fences
  const m = text.match(/```(?:json)?\n?([\s\S]*?)\n?```/);
  if (m) { try { return JSON.parse(m[1]); } catch {} }
  // Try extract first { ... } block
  const m2 = text.match(/(\{[\s\S]*\})/);
  if (m2) { try { return JSON.parse(m2[1]); } catch {} }
  // Fallback: treat whole text as summary
  return {
    verdict: null,
    confidence: 'Moderate',
    summary: text,
    findings: [],
    analysis: [],
    risks: [],
    recommendations: [],
    next: [],
  };
}

/* ---- Spin animation ---- */
const spinStyle = document.createElement('style');
spinStyle.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
document.head.appendChild(spinStyle);

Object.assign(window, {
  AegisContext, useAegis, useLocalStorage,
  toast, ToastProvider,
  Icon, useLucide, Label,
  RiskPill, Verdict, Confidence,
  MetricTile, SectionHead,
  Spinner, CopyBtn,
  AEGIS_SYSTEM_PROMPT, callAegis, parseAegisResponse,
  RISK, VERDICT,
});
