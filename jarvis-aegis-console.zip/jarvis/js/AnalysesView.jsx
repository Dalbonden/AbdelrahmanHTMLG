/* AEGIS Console — Analyses log */
function AnalysesView({ onOpen }) {
  useLucide();
  const rows = [
    { t: "EU mid-market expansion", v: "VALIDATE FIRST", c: "High", d: "Today · 09:12" },
    { t: "$1.2M cloud commit (2-year)", v: "BUILD", c: "Moderate", d: "Yesterday" },
    { t: "Acquire vs build: analytics layer", v: "PIVOT", c: "Moderate", d: "2 days ago" },
    { t: "Series B timing & dilution", v: "VALIDATE FIRST", c: "Low", d: "Last week" },
    { t: "Offshore eng pod — risk review", v: "REJECT", c: "High", d: "Last week" },
  ];
  return (
    <div className="content scrolltrack">
      <div className="content-pad fadeup">
        <SectionHead
          kicker="Decision log"
          title="Analyses"
          right={<button className="btn btn-primary" onClick={onOpen}><Icon name="terminal" cls="ic-16" />New</button>}
        />
        <div className="card" style={{ overflow: "hidden" }}>
          {rows.map((r, i) => (
            <div
              key={i}
              onClick={onOpen}
              style={{
                display: "grid",
                gridTemplateColumns: "1fr auto auto auto",
                gap: 16,
                alignItems: "center",
                padding: "15px 20px",
                borderBottom: i < rows.length - 1 ? "1px solid var(--line)" : "none",
                cursor: "pointer",
                transition: "background .14s",
              }}
              onMouseEnter={e => e.currentTarget.style.background = "var(--bg-raised)"}
              onMouseLeave={e => e.currentTarget.style.background = ""}
            >
              <span style={{ fontSize: 15, color: "var(--fg-1)" }}>{r.t}</span>
              <Confidence level={r.c} />
              <Verdict label={r.v} />
              <span className="label" style={{ minWidth: 92, textAlign: "right" }}>{r.d}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { AnalysesView });
