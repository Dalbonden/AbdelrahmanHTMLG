/* AEGIS Console — app shell & routing */

function PlaceholderView({ title, icon, note }) {
  useLucide();
  return (
    <div className="content matrix-bg" style={{ display: "grid", placeItems: "center" }}>
      <div style={{ textAlign: "center", color: "var(--fg-3)" }}>
        <Icon name={icon} cls="ic-24" />
        <h2 style={{ font: "var(--text-h3)", color: "var(--fg-2)", margin: "12px 0 6px" }}>{title}</h2>
        <p className="label">{note || "NOT YET CONFIGURED"}</p>
      </div>
    </div>
  );
}

const VIEW_META = {
  briefing:    { crumb: "OPERATE",       title: "Briefing" },
  ask:         { crumb: "OPERATE",       title: "Ask AEGIS" },
  analyses:    { crumb: "OPERATE",       title: "Analyses" },
  markets:     { crumb: "INTELLIGENCE",  title: "Markets" },
  portfolio:   { crumb: "INTELLIGENCE",  title: "Portfolio" },
  security:    { crumb: "INTELLIGENCE",  title: "Security" },
  automations: { crumb: "SYSTEM",        title: "Automations" },
  settings:    { crumb: "SYSTEM",        title: "Settings" },
};

function App() {
  const [view, setView] = useState("briefing");
  const [seeded, setSeeded] = useState(false);
  useLucide();

  const goAsk = (withSeed) => { setSeeded(!!withSeed); setView("ask"); };
  const meta = VIEW_META[view];

  let body;
  if      (view === "briefing")    body = <div className="content scrolltrack"><BriefingView onOpenAnalysis={() => goAsk(true)} /></div>;
  else if (view === "ask")         body = <ChatView seeded={seeded} key={seeded ? "s" : "f"} />;
  else if (view === "analyses")    body = <AnalysesView onOpen={() => goAsk(true)} />;
  else if (view === "markets")     body = <MarketsView onAsk={() => goAsk(false)} />;
  else if (view === "security")    body = <SecurityView onAsk={() => goAsk(false)} />;
  else if (view === "portfolio")   body = <PlaceholderView title="Portfolio" icon="briefcase" note="CONNECT PORTFOLIO DATA SOURCE" />;
  else if (view === "automations") body = <PlaceholderView title="Automations" icon="git-branch" note="NO AUTOMATIONS CONFIGURED" />;
  else if (view === "settings")    body = <PlaceholderView title="Settings" icon="settings" note="SYSTEM CONFIGURATION" />;

  return (
    <div className="app">
      <Sidebar active={view} onNav={setView} />
      <div className="main">
        <TopBar crumb={meta.crumb} title={meta.title} />
        {body}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
