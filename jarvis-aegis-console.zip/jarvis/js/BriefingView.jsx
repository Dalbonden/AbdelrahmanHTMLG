/* AEGIS Console — Briefing (dashboard) view */
function BriefingView({ onOpenAnalysis }) {
  useLucide();
  const risks = [
    { item: "EU regulatory load on mid-market GTM", level: "High", trend: "↑" },
    { item: "Single-vendor cloud concentration", level: "Medium", trend: "→" },
    { item: "Burn outpacing net-new ARR", level: "Medium", trend: "↑" },
    { item: "Founder key-person dependency", level: "Critical", trend: "→" },
    { item: "Secrets rotation overdue (3 services)", level: "High", trend: "↓" },
  ];
  return (
    <div className="content-pad fadeup">
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 22 }}>
        <div>
          <Label>Daily briefing · {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}</Label>
          <h1 style={{ font: "var(--text-h1)", margin: "10px 0 0", letterSpacing: "-0.01em" }}>Good morning, Principal.</h1>
          <p style={{ font: "var(--text-body-lg)", color: "var(--fg-2)", margin: "8px 0 0", maxWidth: 640 }}>
            Three items need a decision today. Runway is stable; one risk escalated to <span style={{ color: "var(--critical)" }}>critical</span>.
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => onOpenAnalysis()}><Icon name="terminal" cls="ic-16" />New analysis</button>
      </div>

      <div className="grid-metrics" style={{ marginBottom: 26 }}>
        <MetricTile label="ARR" value="$23.8M" delta="14.2% QoQ" tone="up" />
        <MetricTile label="Burn / mo" value="$640K" delta="6.0% MoM" tone="warn" />
        <MetricTile label="Runway" value="18" unit="mo" delta="stable" tone="muted" />
        <MetricTile label="NRR" value="118%" delta="2.0 pts QoQ" tone="up" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
        <div className="card" style={{ padding: "18px 20px" }}>
          <SectionHead kicker="Risk assessment" title="Active risk matrix" right={<span className="label">5 TRACKED</span>} />
          <div>
            {risks.map((r, i) => (
              <div className="matrix-row" key={i}>
                <span style={{ fontSize: 14, color: "var(--fg-1)" }}>{r.item}</span>
                <span className="label" style={{ color: "var(--fg-3)" }}>{r.trend}</span>
                <RiskPill level={r.level} />
              </div>
            ))}
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card glow" style={{ padding: "18px 20px" }}>
            <Label style={{ color: "var(--accent)" }}>Recommendation · today</Label>
            <h3 style={{ font: "var(--text-h4)", margin: "10px 0 8px" }}>Stage the EU launch — don't commit eng yet.</h3>
            <p style={{ font: "var(--text-body-sm)", color: "var(--fg-2)", margin: "0 0 14px" }}>
              Demand signal is strong but regulatory exposure gates timeline. Run 3 design partners first.
            </p>
            <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
              <Verdict label="VALIDATE FIRST" />
              <Confidence level="High" />
            </div>
          </div>
          <div className="card" style={{ padding: "18px 20px" }}>
            <Label>Awaiting your decision</Label>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 12 }}>
              {["Approve Q3 hiring plan (4 reqs)", "Sign cloud commit — $1.2M / 2yr", "Greenlight security audit vendor"].map((t, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 14, color: "var(--fg-1)", cursor: "pointer" }} onClick={() => onOpenAnalysis()}>
                  <Icon name="circle-dot" cls="ic-16" />
                  <span>{t}</span>
                  <Icon name="arrow-right" cls="ic-16" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { BriefingView });
