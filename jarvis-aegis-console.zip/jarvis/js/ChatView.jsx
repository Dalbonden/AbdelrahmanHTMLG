/* AEGIS Console — Ask AEGIS (structured analysis thread) */

function ExecResponse({ data }) {
  useLucide();
  return (
    <div className="fadeup" style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <div className="card glow" style={{ padding: "18px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <Label style={{ color: "var(--accent)" }}>Executive summary</Label>
          <span style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            {data.verdict && <Verdict label={data.verdict} />}
            <Confidence level={data.confidence} />
          </span>
        </div>
        <p style={{ font: "var(--text-body-lg)", color: "var(--fg-1)", margin: 0 }}>{data.summary}</p>
      </div>

      <div>
        <Label>Key findings</Label>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 10 }}>
          {data.findings.map((f, i) => (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: 12, alignItems: "baseline" }}>
              <span style={{ font: "var(--text-mono)", fontSize: 12, color: "var(--accent)" }}>{String(i + 1).padStart(2, "0")}</span>
              <span style={{ fontSize: 15, color: "var(--fg-1)" }}>{f}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {data.analysis.map((a, i) => (
          <div className="card" key={i} style={{ padding: "14px 16px" }}>
            <Label>{a.head}</Label>
            <p style={{ font: "var(--text-body-sm)", color: "var(--fg-2)", margin: "8px 0 0" }}>{a.body}</p>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: "16px 20px" }}>
        <Label>Risk assessment</Label>
        <div style={{ marginTop: 8 }}>
          {data.risks.map((r, i) => (
            <div className="matrix-row" key={i} style={{ gridTemplateColumns: "1fr auto" }}>
              <span style={{ fontSize: 14, color: "var(--fg-1)" }}>{r.item}<span style={{ color: "var(--fg-3)", display: "block", fontSize: 12.5, marginTop: 2 }}>{r.mitigation}</span></span>
              <RiskPill level={r.level} />
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <div>
          <Label>Recommendations</Label>
          <ol style={{ margin: "10px 0 0", paddingLeft: 18, color: "var(--fg-1)", fontSize: 14, display: "flex", flexDirection: "column", gap: 7 }}>
            {data.recommendations.map((r, i) => <li key={i} style={{ paddingLeft: 4 }}>{r}</li>)}
          </ol>
        </div>
        <div>
          <Label>Next steps</Label>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 10 }}>
            {data.next.map((n, i) => (
              <div key={i} style={{ display: "flex", gap: 9, alignItems: "center", fontSize: 14, color: "var(--fg-1)" }}>
                <Icon name="arrow-right" cls="ic-16" /><span>{n}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const RESPONSES = {
  "eu": {
    summary: "Entering the EU mid-market is directionally correct but premature to build against. The demand signal is real; the binding constraint is regulatory and operational readiness, not product. Stage it: validate with design partners, stand up compliance, then commit engineering.",
    verdict: "VALIDATE FIRST",
    confidence: "High",
    findings: [
      "Inbound from EU accounts is up 41% QoQ with no localized GTM — latent demand is real.",
      "GDPR + data-residency requirements add ~9–13 weeks before a compliant launch is possible.",
      "Two competitors already hold SOC 2 + EU hosting; we trail on trust signals, not features.",
      "Estimated incremental ARR: €2.1–3.4M in year one (moderate confidence).",
    ],
    analysis: [
      { head: "Strategic", body: "Strong fit with up-market motion; widens TAM ~28%. Defensible only if compliance posture leads, not lags." },
      { head: "Financial", body: "€2.1–3.4M Y1 ARR vs ~$480K setup + 1.5 FTE. ROI positive by Q3 of launch year in the base case." },
      { head: "Technical", body: "Requires EU region, data-residency routing, and audit logging. ~6 eng-weeks; no core re-architecture." },
      { head: "Operational", body: "Bottleneck is compliance + local counsel, not engineering. Sequence those first to de-risk the date." },
    ],
    risks: [
      { item: "Regulatory load (GDPR, residency)", mitigation: "Stage launch; engage local counsel before any commit.", level: "High" },
      { item: "Trust gap vs incumbents", mitigation: "Fast-track SOC 2 Type II; publish EU hosting.", level: "Medium" },
      { item: "Burn impact during ramp", mitigation: "Cap to 1.5 FTE until 3 signed design partners.", level: "Medium" },
    ],
    recommendations: [
      "Sign 3 EU design partners before committing engineering.",
      "Kick off SOC 2 Type II and EU region provisioning in parallel.",
      "Set a go/no-go gate at 60 days tied to partner conversion.",
    ],
    next: ["Draft design-partner shortlist", "Brief counsel on residency", "Schedule 60-day go/no-go", "Model burn sensitivity"],
  },
  "cloud": {
    summary: "The $1.2M / 2-year cloud commit is financially justified given current trajectory, but only if growth assumptions hold above base case. The risk is overcommitting before Series B closes. Recommend a staged approach: execute 12-month increment now, negotiate option on the second year.",
    verdict: "VALIDATE FIRST",
    confidence: "Moderate",
    findings: [
      "Current cloud spend: ~$38K/mo. Committed rate saves ~22% ($100K+ NPV over 2 years).",
      "Spend scales predictably with ARR; growth stall is the primary risk to ROI.",
      "Series B timeline is 4–6 months out — committing 2 years before close adds balance sheet drag.",
      "Vendor lock-in risk is moderate; egress costs for migration estimated at $60–90K.",
    ],
    analysis: [
      { head: "Financial", body: "$100K+ NPV savings vs. on-demand. Savings materialize only if ARR grows ≥15% annually through the term." },
      { head: "Strategic", body: "Locks in current infrastructure paradigm. Acceptable if no major architectural shift is planned." },
      { head: "Technical", body: "No re-architecture required. Existing usage patterns map cleanly to committed tier." },
      { head: "Operational", body: "Procurement is straightforward. Key risk is Series B dilution optics if large commitments are visible on the cap table." },
    ],
    risks: [
      { item: "Growth stall renders commit uneconomical", mitigation: "Model break-even at 10% ARR growth; acceptable risk.", level: "Medium" },
      { item: "Series B investors flag long-term vendor commitment", mitigation: "Stage: 12-month now, option on year 2.", level: "Medium" },
      { item: "Architecture shift (e.g., multi-cloud)", mitigation: "Assess roadmap. Current plan has no multi-cloud requirement.", level: "Low" },
    ],
    recommendations: [
      "Execute 12-month committed tier immediately — clear ROI.",
      "Negotiate option on year 2, exercisable post-Series B close.",
      "Document break-even analysis for investor data room.",
    ],
    next: ["Draft 12-month commit terms", "Negotiate year-2 option clause", "Add to Series B data room", "Model sensitivity at 10%/15%/20% ARR growth"],
  },
  "runway": {
    summary: "Runway at 18 months is stable but not comfortable. At current burn, you have adequate buffer for a Series B process but no room for error. One moderate growth miss extends the raise timeline into danger territory. Recommend burn tightening by $80–100K/mo to extend runway to 22+ months.",
    verdict: "BUILD",
    confidence: "High",
    findings: [
      "Current burn: $640K/mo. Current runway: ~18 months at flat burn.",
      "Series B process typically takes 4–6 months from first meeting to close. You have buffer — barely.",
      "NRR at 118% provides natural burn offset if expansion stays on track.",
      "A $80K/mo reduction (12.5%) buys 3–4 months of additional runway with minimal operational impact.",
    ],
    analysis: [
      { head: "Financial", body: "18-month runway is the institutional minimum comfort zone for a Series B raise. Tight but workable if process starts within 60 days." },
      { head: "Strategic", body: "Extending runway reduces Series B timing pressure, which directly improves negotiating position on valuation and terms." },
      { head: "Technical", body: "No technical debt forced by current runway. Engineering capacity is appropriately sized." },
      { head: "Operational", body: "Primary burn lever is headcount. Four open reqs should be prioritized by direct revenue impact before approval." },
    ],
    risks: [
      { item: "Series B process extends beyond 6 months", mitigation: "Begin outreach within 30 days. Don't wait for perfect metrics.", level: "High" },
      { item: "Growth miss compresses runway further", mitigation: "Model downside at -20% ARR growth; have a burn plan ready.", level: "Medium" },
      { item: "Key hires lost to slower burn pace", mitigation: "Approve top-priority roles; defer speculative reqs.", level: "Low" },
    ],
    recommendations: [
      "Start Series B outreach within 30 days — don't wait.",
      "Reduce burn by $80–100K/mo via headcount discipline (defer 2 of 4 open reqs).",
      "Set monthly runway review with board — flag at 15-month threshold.",
    ],
    next: ["Identify 3 lead Series B investors", "Model burn reduction scenarios", "Prioritize open reqs by revenue impact", "Set 15-month runway alert"],
  },
  "default": {
    summary: "Analysis complete. The proposed direction carries meaningful opportunity but requires structured validation before full resource commitment. Recommend a staged approach with clear go/no-go criteria at each gate.",
    verdict: "VALIDATE FIRST",
    confidence: "Moderate",
    findings: [
      "Sufficient market signal to justify validation investment — not full build.",
      "Primary risk is resource overcommitment before demand is confirmed.",
      "Comparable initiatives have succeeded with a 60-day design-partner program before engineering commit.",
      "Financial exposure in validation phase is bounded and acceptable.",
    ],
    analysis: [
      { head: "Strategic", body: "Aligns with stated growth priorities. Success here reinforces core positioning." },
      { head: "Financial", body: "Validation cost: ~$40–80K. Full build cost: 10–15x. Gate the spending." },
      { head: "Technical", body: "No architectural blockers identified at this stage. Full assessment needed at go decision." },
      { head: "Operational", body: "Execution risk is moderate. Requires a dedicated owner with clear authority." },
    ],
    risks: [
      { item: "Validation drags without a deadline", mitigation: "Set a hard 60-day gate with defined success criteria.", level: "Medium" },
      { item: "Competitive window closes during validation", mitigation: "Monitor market weekly; accelerate if signal is strong.", level: "Medium" },
      { item: "Team distraction from core priorities", mitigation: "Assign a single owner; don't staff-up until go decision.", level: "Low" },
    ],
    recommendations: [
      "Run a 60-day validation sprint with 3 design partners.",
      "Define success criteria before starting — don't move the goalposts.",
      "Assign a single decision-owner with authority to call the gate.",
    ],
    next: ["Define success criteria", "Identify design partners", "Set 60-day go/no-go date", "Assign decision-owner"],
  },
};

function pickResponse(text) {
  const t = text.toLowerCase();
  if (t.includes("eu") || t.includes("europe") || t.includes("expand")) return RESPONSES.eu;
  if (t.includes("cloud") || t.includes("commit") || t.includes("1.2")) return RESPONSES.cloud;
  if (t.includes("runway") || t.includes("burn") || t.includes("18")) return RESPONSES.runway;
  return RESPONSES.default;
}

function ChatView({ seeded }) {
  useLucide();
  const [thread, setThread] = useState(seeded ? [
    { role: "user", text: "Should we expand into the EU mid-market this year?" },
    { role: "aegis", data: RESPONSES.eu }
  ] : []);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [thread, thinking]);

  const send = (text) => {
    const q = (text ?? input).trim();
    if (!q) return;
    setThread((t) => [...t, { role: "user", text: q }]);
    setInput("");
    setThinking(true);
    setTimeout(() => {
      setThinking(false);
      setThread((t) => [...t, { role: "aegis", data: pickResponse(q) }]);
    }, 1400);
  };

  const suggestions = [
    "Should we expand into the EU mid-market?",
    "Evaluate the $1.2M cloud commit",
    "Stress-test our 18-month runway",
  ];

  return (
    <React.Fragment>
      <div className="content scrolltrack" ref={scrollRef}>
        <div className="content-pad">
          {thread.length === 0 && (
            <div className="fadeup" style={{ paddingTop: 40, textAlign: "center" }}>
              <div style={{ color: "var(--fg-2)", display: "inline-flex" }}>
                <img src="assets/logo-mark.svg" width="48" alt="AEGIS" />
              </div>
              <h1 style={{ font: "var(--text-h2)", margin: "16px 0 6px" }}>Ask AEGIS</h1>
              <p style={{ color: "var(--fg-3)", margin: "0 auto 24px", maxWidth: 460 }}>Pose a decision. Get an executive-grade analysis: summary, findings, risks, and a recommendation.</p>
              <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap" }}>
                {suggestions.map((s, i) => (
                  <button key={i} className="btn btn-secondary" style={{ fontSize: 13 }} onClick={() => send(s)}>{s}</button>
                ))}
              </div>
            </div>
          )}
          <div style={{ display: "flex", flexDirection: "column", gap: 24, marginTop: thread.length ? 0 : 32 }}>
            {thread.map((m, i) => m.role === "user"
              ? (
                <div key={i} style={{ alignSelf: "flex-end", maxWidth: "70%" }}>
                  <div style={{ background: "var(--bg-raised)", border: "1px solid var(--line)", borderRadius: "var(--r-lg)", padding: "12px 16px", fontSize: 15 }}>{m.text}</div>
                </div>
              )
              : (
                <div key={i} style={{ display: "flex", gap: 12 }}>
                  <div style={{ flex: "none", width: 30, height: 30 }}>
                    <img src="assets/logo-mark.svg" width="30" alt="AEGIS" />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}><ExecResponse data={m.data} /></div>
                </div>
              ))}
            {thinking && (
              <div style={{ display: "flex", gap: 12, alignItems: "center", color: "var(--fg-3)" }}>
                <div style={{ flex: "none", width: 30, height: 30 }}>
                  <img src="assets/logo-mark.svg" width="30" alt="AEGIS" />
                </div>
                <span className="label">ANALYZING<span style={{ opacity: 0.6 }}>…</span></span>
              </div>
            )}
          </div>
        </div>
      </div>
      <div style={{ borderTop: "1px solid var(--line)", padding: "16px 32px", background: "var(--bg-app)" }}>
        <div style={{ maxWidth: 1080, margin: "0 auto", display: "flex", gap: 10, alignItems: "center", background: "var(--bg-inset)", border: "1px solid var(--line-strong)", borderRadius: "var(--r-lg)", padding: "8px 8px 8px 16px" }}>
          <Icon name="terminal" cls="ic-18" />
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") send(); }}
            placeholder="Ask AEGIS to analyze a decision…"
            style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "var(--fg-1)", font: "var(--text-body)" }}
          />
          <button className="btn btn-primary" onClick={() => send()} disabled={thinking || !input.trim()}>
            <Icon name="arrow-up" cls="ic-16" />Run
          </button>
        </div>
      </div>
    </React.Fragment>
  );
}
Object.assign(window, { ChatView, ExecResponse });
