/* AEGIS Console — Markets intelligence view */
function MarketsView({ onAsk }) {
  useLucide();
  const signals = [
    { ticker: "SAAS INDEX", val: "▲ 3.2%", desc: "Leading SaaS multiples expanded on Fed rate signal", tone: "up" },
    { ticker: "EUR/USD", val: "1.0847", desc: "Euro strengthened; favorable for EU expansion unit economics", tone: "up" },
    { ticker: "VC DEAL FLOW", val: "▼ 12%", desc: "Series B deal count down QoQ; valuation discipline tightening", tone: "down" },
    { ticker: "TALENT INDEX", val: "→ 0.4%", desc: "Engineering compensation flat; no significant wage pressure", tone: "muted" },
  ];
  const intel = [
    { head: "Competitor A", body: "Raised Series C at 14x ARR. Now moving up-market aggressively. EU launch announced for Q3.", level: "High" },
    { head: "Competitor B", body: "Lost 2 enterprise logos to us last month. Pricing pressure likely incoming.", level: "Low" },
    { head: "Regulatory", body: "EU AI Act compliance deadline approaching. Affects our inference pipeline — legal review needed.", level: "Critical" },
  ];
  return (
    <div className="content scrolltrack">
      <div className="content-pad fadeup">
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 22 }}>
          <div>
            <Label>Market intelligence · {new Date().toLocaleDateString("en-US", { month: "long", day: "numeric" })}</Label>
            <h1 style={{ font: "var(--text-h1)", margin: "10px 0 0", letterSpacing: "-0.01em" }}>Markets</h1>
          </div>
          <button className="btn btn-primary" onClick={onAsk}><Icon name="terminal" cls="ic-16" />Ask AEGIS</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {signals.map((s, i) => {
            const col = s.tone === "up" ? "var(--positive)" : s.tone === "down" ? "var(--critical)" : "var(--fg-3)";
            return (
              <div className="card tile" key={i}>
                <Label>{s.ticker}</Label>
                <span className="metric" style={{ fontSize: 22, color: col }}>{s.val}</span>
                <span style={{ font: "var(--text-mono)", fontSize: 11, color: "var(--fg-3)", lineHeight: 1.4 }}>{s.desc}</span>
              </div>
            );
          })}
        </div>

        <div className="card" style={{ padding: "18px 20px" }}>
          <SectionHead kicker="Competitive & regulatory" title="Intelligence feed" right={<span className="label">{intel.length} SIGNALS</span>} />
          <div>
            {intel.map((r, i) => (
              <div className="matrix-row" key={i}>
                <span style={{ fontSize: 14, color: "var(--fg-1)" }}>
                  <span style={{ color: "var(--fg-3)", font: "var(--text-mono)", fontSize: 11, textTransform: "uppercase", letterSpacing: ".1em", marginRight: 10 }}>{r.head}</span>
                  {r.body}
                </span>
                <RiskPill level={r.level} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { MarketsView });
