/* AEGIS Console — Security intelligence view */
function SecurityView({ onAsk }) {
  useLucide();
  const threats = [
    { item: "Secrets rotation overdue — 3 production services", level: "Critical", age: "14 days" },
    { item: "Unpatched CVE-2024-3094 (xz-utils) on 2 hosts", level: "High", age: "7 days" },
    { item: "Admin account without MFA — 1 user", level: "High", age: "3 days" },
    { item: "S3 bucket with public-read ACL (non-CDN)", level: "Medium", age: "21 days" },
    { item: "Stale API keys in CI environment variables", level: "Medium", age: "45 days" },
    { item: "SSL cert expiry in 18 days — staging.app", level: "Low", age: "Today" },
  ];
  const counts = { Critical: 1, High: 2, Medium: 2, Low: 1 };
  return (
    <div className="content scrolltrack">
      <div className="content-pad fadeup">
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 22 }}>
          <div>
            <Label>Security posture · live scan</Label>
            <h1 style={{ font: "var(--text-h1)", margin: "10px 0 0", letterSpacing: "-0.01em" }}>Security</h1>
          </div>
          <button className="btn btn-primary" onClick={onAsk}><Icon name="terminal" cls="ic-16" />Ask AEGIS</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[["Critical", "var(--critical)"], ["High", "var(--orange-400)"], ["Medium", "var(--warning)"], ["Low", "var(--positive)"]].map(([lvl, col]) => (
            <div className="card tile" key={lvl}>
              <Label style={{ color: col }}>{lvl}</Label>
              <span className="metric" style={{ fontSize: 28, color: "var(--fg-1)" }}>{counts[lvl]}</span>
              <span style={{ font: "var(--text-mono)", fontSize: 12, color: "var(--fg-3)" }}>open finding{counts[lvl] !== 1 ? "s" : ""}</span>
            </div>
          ))}
        </div>

        <div className="card" style={{ padding: "18px 20px" }}>
          <SectionHead kicker="Active findings" title="Threat register" right={<span className="label">{threats.length} OPEN</span>} />
          <div>
            {threats.map((r, i) => (
              <div className="matrix-row" key={i}>
                <span style={{ fontSize: 14, color: "var(--fg-1)" }}>
                  {r.item}
                  <span style={{ color: "var(--fg-4)", display: "inline", marginLeft: 10, fontSize: 12 }}>· {r.age} ago</span>
                </span>
                <RiskPill level={r.level} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { SecurityView });
