/* AEGIS Console — top bar */
function TopBar({ crumb, title }) {
  useLucide();
  const [clock, setClock] = useState("");
  useEffect(() => {
    const tick = () => {
      const d = new Date();
      const p = (n) => String(n).padStart(2, "0");
      setClock(`${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())} UTC`);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <header className="topbar">
      <span className="crumb">{crumb}</span>
      <h1>{title}</h1>
      <div className="topbar-search">
        <Icon name="search" cls="ic-16" />
        <span>Search analyses, markets, files…</span>
      </div>
      <div className="topbar-meta">
        <span style={{ display: "flex", alignItems: "center", gap: 7, color: "var(--accent)" }}><span className="dot" style={{ background: "var(--accent)" }}></span>LIVE</span>
        <span>{clock}</span>
      </div>
    </header>
  );
}
Object.assign(window, { TopBar });
