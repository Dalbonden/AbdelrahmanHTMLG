/* AEGIS Console — shared primitives */
const { useState, useEffect, useRef } = React;

function Icon({ name, cls = "" }) {
  return <i data-lucide={name} className={"lucide " + cls}></i>;
}

function useLucide() {
  useEffect(() => { if (window.lucide) window.lucide.createIcons(); });
}

function Label({ children, style }) {
  return <span className="label" style={style}>{children}</span>;
}

const RISK = {
  Low:      { c: "var(--positive)", bg: "var(--positive-soft)" },
  Medium:   { c: "var(--warning)",  bg: "var(--warning-soft)" },
  High:     { c: "var(--orange-400)", bg: "rgba(224,123,59,.12)" },
  Critical: { c: "var(--critical)", bg: "var(--critical-soft)" },
};
function RiskPill({ level }) {
  const r = RISK[level] || RISK.Low;
  return <span className="pill" style={{ background: r.bg, color: r.c }}><span className="dot"></span>{level}</span>;
}

const VERDICT = {
  BUILD:            { c: "var(--positive)", bg: "var(--positive-soft)" },
  "VALIDATE FIRST": { c: "var(--warning)",  bg: "var(--warning-soft)" },
  PIVOT:            { c: "var(--steel-300)", bg: "var(--data-soft)" },
  REJECT:           { c: "var(--critical)", bg: "var(--critical-soft)" },
};
function Verdict({ label }) {
  const v = VERDICT[label] || VERDICT.BUILD;
  return <span style={{ font: "600 13px/1 var(--font-sans)", padding: "6px 13px", borderRadius: "var(--r-sm)", background: v.bg, color: v.c, letterSpacing: ".02em" }}>{label}</span>;
}

function Confidence({ level }) {
  return <span className="pill" style={{ background: "var(--data-soft)", color: "var(--steel-300)" }}>Confidence: {level}</span>;
}

function MetricTile({ label, value, delta, tone = "muted", unit }) {
  const toneColor = { up: "var(--positive)", warn: "var(--warning)", down: "var(--critical)", muted: "var(--fg-3)" }[tone];
  const arrow = tone === "up" ? "▲" : tone === "down" ? "▼" : tone === "warn" ? "▲" : "";
  return (
    <div className="card tile">
      <Label>{label}</Label>
      <span className="metric">{value}{unit && <span style={{ fontSize: 15, color: "var(--fg-3)" }}> {unit}</span>}</span>
      <span style={{ font: "var(--text-mono)", fontSize: 12, color: toneColor }}>{arrow && arrow + " "}{delta}</span>
    </div>
  );
}

function SectionHead({ kicker, title, right }) {
  return (
    <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 14 }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {kicker && <Label>{kicker}</Label>}
        <h2 style={{ font: "var(--text-h3)", margin: 0, color: "var(--fg-1)" }}>{title}</h2>
      </div>
      {right}
    </div>
  );
}

Object.assign(window, { Icon, useLucide, Label, RiskPill, Verdict, Confidence, MetricTile, SectionHead, RISK });
